// 自动尺寸验证
//
// 为什么不能只看「有没有文字出现」：读数是个**数字**，而数字最容易悄悄错。
// 少乘一个 scale、把屏幕距离当成模型距离、y 忘了翻 —— 每一种都会渲染出一个
// 看起来完全正常的标签，只是值是错的。所以这里的核心断言是：
//
//   标签里的长度 == 两次点击真实落点之间的模型距离
//
// 落点从页面暴露的 `window.__unicadCursor`（工具实际用到的 effective 点）读，
// 所以它天然绕开了捕捉的干扰：捕捉把点挪到哪里，期望值就跟着挪到哪里。
//
// 其余各条：
//   - 绘制中输入光标移动时读数要跟着变（证明它是实时的，不是一次性算的）
//   - 尺寸关闭后标签全消失、重新打开后全回来（闭环，排除「只是这次没渲染」）
//   - 标签不得吃鼠标事件（pointer-events: none）
//   - 所有标签都被夹在画布内（clampToView 生效，边缘不会半个数字）
//   - 关闭状态下绘制中也不出标签（开关真的管到两条来源）
//
// 用法：node scripts/verify-dims.mjs [url] [--shot]

import { spawn } from 'node:child_process';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const CHROME = 'C:/Program Files/Google/Chrome/Application/chrome.exe';
const url = process.argv.slice(2).find((a) => !a.startsWith('--')) ?? 'http://127.0.0.1:5273/';

try {
  const probe = await fetch(url, { method: 'HEAD' });
  if (!probe.ok) throw new Error(`HTTP ${probe.status}`);
} catch (e) {
  console.error(`❌ 无法访问 ${url}（${e.message}）—— 请先 npm run dev 或 npm run preview 再跑本检查。`);
  process.exit(2);
}

const port = 9700 + Math.floor(Math.random() * 100);
const profile = mkdtempSync(join(tmpdir(), 'unicad-dims-'));

const chrome = spawn(
  CHROME,
  [
    '--headless=new',
    '--enable-unsafe-swiftshader',
    '--use-gl=angle',
    '--use-angle=swiftshader',
    `--remote-debugging-port=${port}`,
    '--no-first-run',
    '--no-default-browser-check',
    `--user-data-dir=${profile}`,
    '--window-size=1440,900',
    'about:blank',
  ],
  { stdio: 'ignore' },
);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

let list = null;
for (let i = 0; i < 80; i++) {
  try {
    list = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
    if (list.length) break;
  } catch {
    /* not up yet */
  }
  await sleep(250);
}
const page = list.find((t) => t.type === 'page');
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((res, rej) => {
  ws.onopen = res;
  ws.onerror = rej;
});

let id = 0;
const pending = new Map();
const problems = [];

ws.onmessage = (ev) => {
  const m = JSON.parse(ev.data);
  if (m.id && pending.has(m.id)) {
    const resolve = pending.get(m.id);
    pending.delete(m.id);
    resolve(m.result);
    return;
  }
  if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') {
    problems.push('console.error: ' + m.params.args.map((a) => a.value ?? a.description).join(' '));
  }
  if (m.method === 'Runtime.exceptionThrown') {
    const d = m.params.exceptionDetails;
    problems.push('exception: ' + (d?.exception?.description ?? d?.text));
  }
};

const send = (method, params = {}) => {
  const i = ++id;
  ws.send(JSON.stringify({ id: i, method, params }));
  return new Promise((r) => pending.set(i, r));
};

const evaluate = async (expr) =>
  (await send('Runtime.evaluate', { expression: expr, awaitPromise: true, returnByValue: true }))
    .result?.value;

await send('Runtime.enable');
await send('Page.enable');

const settle = () =>
  evaluate(
    `new Promise(r => requestAnimationFrame(() => requestAnimationFrame(() => requestAnimationFrame(r))))`,
  );

const waitForApp = async () => {
  for (let i = 0; i < 80; i++) {
    if (await evaluate(`!!document.querySelector('canvas.canvas-gl')`)) break;
    await sleep(250);
  }
  for (let i = 0; i < 60; i++) {
    const t = (await evaluate(`document.body ? document.body.innerText : ''`)) ?? '';
    if (/WASM|已就绪/.test(t)) break;
    await sleep(250);
  }
  // 示例图纸是在挂载后 120ms 才 zoomToFit 的，等它稳定再取坐标。
  await sleep(400);
  await settle();
};

// ---------------------------------------------------------------------------
// 探针
// ---------------------------------------------------------------------------

const canvasBox = () =>
  evaluate(`(() => {
    const c = document.querySelector('canvas.canvas-gl');
    if (!c) return null;
    const r = c.getBoundingClientRect();
    return { x: r.x, y: r.y, w: r.width, h: r.height };
  })()`);

/** 所有尺寸标签：文本、类别、以及相对画布的矩形。 */
const readLabels = () =>
  evaluate(`(() => {
    const layer = document.querySelector('.dim-layer');
    if (!layer) return null;
    const lb = layer.getBoundingClientRect();
    return Array.from(layer.children)
      .filter(n => n.style.display !== 'none')
      .map(n => {
        const r = n.getBoundingClientRect();
        return {
          text: n.textContent,
          kind: n.classList.contains('live') ? 'live' : 'selected',
          // 中心点：位置断言比的是它，不是左上角。
          cx: (r.left + r.right) / 2 - lb.left,
          cy: (r.top + r.bottom) / 2 - lb.top,
          left: r.left - lb.left, right: r.right - lb.left,
          top: r.top - lb.top, bottom: r.bottom - lb.top,
        };
      });
  })()`);

/** 工具实际使用的落点（世界坐标）。捕捉把它挪到哪里，这里就是哪里。 */
const cursorWorld = () => evaluate(`window.__unicadCursor ? {x: window.__unicadCursor.x, y: window.__unicadCursor.y} : null`);

const viewScale = () => evaluate(`window.__unicadView ? window.__unicadView.scale : null`);

const activeToolTitle = () =>
  evaluate(`(() => {
    const b = document.querySelector('.ribbon .tool-btn.active');
    return b ? b.title : null;
  })()`);

const dimsToggleTitle = () =>
  evaluate(`(() => {
    const b = [...document.querySelectorAll('.tool-btn[title]')]
      .find(x => x.title.includes('自动尺寸'));
    return b ? b.title : null;
  })()`);

// ---------------------------------------------------------------------------
// 输入
// ---------------------------------------------------------------------------

const moveMouse = async (x, y) => {
  await send('Input.dispatchMouseEvent', { type: 'mouseMoved', x, y, button: 'none', buttons: 0 });
};

const clickAt = async (x, y) => {
  await send('Input.dispatchMouseEvent', { type: 'mouseMoved', x, y, button: 'none', buttons: 0 });
  await sleep(30);
  await send('Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', buttons: 1, clickCount: 1 });
  await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', buttons: 0, clickCount: 1 });
  await sleep(110);
};

const clickSel = async (sel) => {
  const r = await evaluate(`(() => {
    const e = document.querySelector(${JSON.stringify(sel)});
    if (!e) return null;
    const b = e.getBoundingClientRect();
    return { x: b.x + b.width / 2, y: b.y + b.height / 2, w: b.width, h: b.height };
  })()`);
  if (!r || r.w <= 0 || r.h <= 0) return false;
  await clickAt(r.x, r.y);
  return true;
};

const pressKey = async (key, code, vk, modifiers = 0) => {
  await send('Input.dispatchKeyEvent', {
    type: 'rawKeyDown', modifiers, key, code,
    windowsVirtualKeyCode: vk, nativeVirtualKeyCode: vk,
  });
  await send('Input.dispatchKeyEvent', {
    type: 'keyUp', modifiers, key, code,
    windowsVirtualKeyCode: vk, nativeVirtualKeyCode: vk,
  });
  await sleep(110);
};

// ---------------------------------------------------------------------------
// 断言
// ---------------------------------------------------------------------------

const failures = [];
const check = (name, ok, detail = '') => {
  console.log(`${ok ? '✓' : '✗'} ${name}${detail ? `  — ${detail}` : ''}`);
  if (!ok) failures.push(name);
};

/** 从 `48.251  ∠26.57°` 里抠出第一个数字。 */
const firstNumber = (s) => {
  const m = String(s).match(/-?\d+(?:\.\d+)?/);
  return m ? Number(m[0]) : NaN;
};
const angleOf = (s) => {
  const m = String(s).match(/∠\s*(-?\d+(?:\.\d+)?)\s*°/);
  return m ? Number(m[1]) : NaN;
};

console.log(`\n目标: ${url}\n`);

await send('Page.navigate', { url });
await waitForApp();

const box = await canvasBox();
if (!box) {
  console.error('❌ 找不到画布');
  process.exit(2);
}

// ---- 0. 覆盖层本身 ---------------------------------------------------------

check('画布内存在 .dim-layer 覆盖层', (await evaluate(`!!document.querySelector('.dim-layer')`)) === true);
const pe = await evaluate(`(() => {
  const l = document.querySelector('.dim-layer');
  return l ? getComputedStyle(l).pointerEvents : null;
})()`);
check('覆盖层不吃鼠标事件（pointer-events: none）', pe === 'none', `= ${pe}`);

const labels0 = await readLabels();
check('初始状态：没有任何尺寸标签', Array.isArray(labels0) && labels0.length === 0, `实测 ${labels0?.length}`);

const readEntityCount = () =>
  evaluate(`(() => {
    const m = document.body.innerText.match(/图元\\s+(\\d+)/);
    return m ? Number(m[1]) : null;
  })()`);
const ent0 = await readEntityCount();
check('示例图纸的图元数可读', Number.isFinite(ent0), `${ent0}`);

// ---- 1. 绘制中：实时读数 ---------------------------------------------------

await pressKey('l', 'KeyL', 76);
const toolAfterL = await activeToolTitle();
check('按 L 切到直线工具', !!toolAfterL && toolAfterL.startsWith('直线'), `${toolAfterL}`);

// 落点选在示例图纸的中上部空白处（工具用 effective 点，会读回来做期望值，
// 所以即使被捕捉挪走也不影响断言）。
const ax = box.x + box.w * 0.3;
const ay = box.y + box.h * 0.45;
const bx = box.x + box.w * 0.62;
const by = box.y + box.h * 0.45;

// 还没定第一点 → 没有 anchor，也就没有读数。
await moveMouse(ax, ay);
await settle();
const noAnchor = await readLabels();
check('未指定起点时不出读数', noAnchor.length === 0, `实测 ${noAnchor.length}`);

await clickAt(ax, ay);
const p1 = await cursorWorld();
check('已记录起点（anchor 建立）', !!p1, p1 ? `(${p1.x.toFixed(2)}, ${p1.y.toFixed(2)})` : 'n/a');

// 移动到一个中间位置，记下第一个读数。
await moveMouse((ax + bx) / 2, (ay + by) / 2);
await settle();
const near = await readLabels();
check('指定起点后出现 1 个实时读数', near.length === 1 && near[0]?.kind === 'live', `${near.length} 个`);

const lenNear = firstNumber(near[0]?.text ?? '');
check('实时读数是数字', Number.isFinite(lenNear) && lenNear > 0, `「${near[0]?.text}」→ ${lenNear}`);

/**
 * 标签必须落在尺寸线**外侧** `offset + gap` 像素处。
 *
 * 位置算错的话标注会贴在别的地方 —— 而「有个数字出现在屏幕上」看起来完全
 * 正常。这里把期望位置按公式重算一遍，再和实际渲染出来的中心比。
 */
const expectLabelAt = async (a, b) => {
  const view = await evaluate(
    `window.__unicadView ? JSON.parse(JSON.stringify(window.__unicadView)) : null`,
  );
  const sOf = (p) => ({
    x: (p.x - view.center.x) / view.scale + view.width / 2,
    y: view.height / 2 - (p.y - view.center.y) / view.scale,
  });
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const L = Math.hypot(dx, dy);
  const nx = -dy / L;
  const ny = dx / L;
  const off = 18 * view.scale;
  const onLine = sOf({ x: (a.x + b.x) / 2 + nx * off, y: (a.y + b.y) / 2 + ny * off });
  // 模型法向 → 屏幕方向只翻 y；文字再沿它往外推 11px。
  return { x: onLine.x + nx * 11, y: onLine.y - ny * 11 };
};
const wantNear = await expectLabelAt(p1, await cursorWorld());
check(
  '实时读数落在尺寸线外侧 29px 处（不是随手贴在某个角落）',
  near[0] && Math.hypot(near[0].cx - wantNear.x, near[0].cy - wantNear.y) <= 2,
  near[0] ? `实测 (${near[0].cx.toFixed(1)},${near[0].cy.toFixed(1)}) vs 期望 (${wantNear.x.toFixed(1)},${wantNear.y.toFixed(1)})` : 'n/a',
);

// 移到终点，读数必须变大 —— 这才说明它是跟着光标实时算的。
await moveMouse(bx, by);
await settle();
const far = await readLabels();
const lenFar = firstNumber(far[0]?.text ?? '');
check('读数随光标移动而更新（更远 → 更大）', lenFar > lenNear * 1.05, `${lenNear} → ${lenFar}`);
check(
  '实时读数位置跟着尺寸线走（不是钉死的）',
  far[0] && near[0] && (Math.abs(far[0].cx - near[0].cx) > 1 || Math.abs(far[0].cy - near[0].cy) > 1),
  near[0] && far[0] ? `(${near[0].cx.toFixed(0)},${near[0].cy.toFixed(0)}) → (${far[0].cx.toFixed(0)},${far[0].cy.toFixed(0)})` : 'n/a',
);

// ---- 2. 选中态：长度必须等于真实几何 ---------------------------------------

const p2 = await cursorWorld();
await clickAt(bx, by);

check('提交后实时读数消失', (await readLabels()).length === 0, `实测 ${(await readLabels()).length}`);

// 直线工具是**连续**的：落一点即提交一段，命令不退出。所以必须显式结束命令，
// 否则下一次点击会被当成「下一点」，又画出一条线 —— 而症状是「选中不了」，
// 看起来像是拾取坏了。第一版脚本就栽在这里（图元数 10 而不是 9 是唯一线索）。
await pressKey('Escape', 'Escape', 27);
const ent1 = await readEntityCount();
check(
  '结束命令后图元数恰好 +1（点击没有变成第二条线）',
  ent1 === (ent0 ?? 0) + 1,
  `${ent0} → ${ent1}`,
);

const wantLen = Math.hypot(p2.x - p1.x, p2.y - p1.y);
const wantDeg = (() => {
  const deg = (Math.atan2(p2.y - p1.y, p2.x - p1.x) * 180) / Math.PI;
  return ((deg % 360) + 360) % 360;
})();

// 点线段中点把它选中（选择工具的拾取容差以内）。
await clickAt((ax + bx) / 2, (ay + by) / 2);
await settle();
const sel = await readLabels();
check('选中刚画的直线后出现 1 个尺寸标签', sel.length === 1 && sel[0]?.kind === 'selected', `${sel.length} 个`);

const gotLen = firstNumber(sel[0]?.text ?? '');
const gotDeg = angleOf(sel[0]?.text ?? '');
// 容差 0.5 %：标签按 fmt() 保留 3 位小数，几何本身是精确的。
check(
  '标签长度 == 两次点击真实落点之间的距离',
  Number.isFinite(gotLen) && Math.abs(gotLen - wantLen) <= Math.max(0.005 * wantLen, 0.002),
  `标签 ${gotLen} vs 几何 ${wantLen.toFixed(3)}`,
);
check(
  '标签角度 == 该直线的方位角',
  Number.isFinite(gotDeg) && Math.abs(gotDeg - wantDeg) <= 0.05,
  `标签 ${gotDeg}° vs 几何 ${wantDeg.toFixed(2)}°`,
);

// ---- 3. 闭合轮廓：尺寸线必须画在图形外侧 -----------------------------------
//
// 单看一条边判断不出「外侧」（两侧完全对称），所以朝向要看**整批选中对象**的
// 包围盒。不做这件事的话，矩形的左右两条竖边会把尺寸线画进内部、压在别的图元
// 上 —— 图看着乱，但每个数字本身都是对的，只有位置断言抓得住。

const selectToolByTitle = async (name) => {
  const ok = await evaluate(`(() => {
    const b = [...document.querySelectorAll('.tool-btn[title]')]
      .find(x => x.title.startsWith(${JSON.stringify(`${name} (`)}));
    if (b) b.click();
    return !!b;
  })()`);
  await sleep(140);
  return ok;
};

const viewInfo = await evaluate(
  `window.__unicadView ? JSON.parse(JSON.stringify(window.__unicadView)) : null`,
);
const toScreen = (p) => ({
  x: (p.x - viewInfo.center.x) / viewInfo.scale + viewInfo.width / 2,
  y: viewInfo.height / 2 - (p.y - viewInfo.center.y) / viewInfo.scale,
});

check('能按 title 命中矩形工具', await selectToolByTitle('矩形'));

const rx1 = box.x + box.w * 0.17;
const ry1 = box.y + box.h * 0.72;
const rx2 = box.x + box.w * 0.47;
const ry2 = box.y + box.h * 0.92;
await clickAt(rx1, ry1);
const r1 = await cursorWorld();
await clickAt(rx2, ry2);
const r2 = await cursorWorld();
await settle();

const s1 = toScreen(r1);
const s2 = toScreen(r2);
const rTop = Math.min(s1.y, s2.y);
const rBottom = Math.max(s1.y, s2.y);

// 点在矩形左边框上把它选中（整条轮廓是一条闭合多段线）。
await clickAt(rx1, (ry1 + ry2) / 2);
await settle();
const rectLabels = await readLabels();
check('选中矩形后出现 1 条尺寸标签', rectLabels.length === 1 && rectLabels[0]?.kind === 'selected', `${rectLabels.length} 个`);
check('矩形标签是总长（Σ）', /^Σ/.test(rectLabels[0]?.text ?? ''), `「${rectLabels[0]?.text}」`);
check(
  '尺寸线画在图形外侧（不横穿内部）',
  !!rectLabels[0] && (rectLabels[0].cy < rTop - 8 || rectLabels[0].cy > rBottom + 8),
  rectLabels[0]
    ? `标签 y ${rectLabels[0].cy.toFixed(0)} vs 图形 y ${rTop.toFixed(0)}…${rBottom.toFixed(0)}`
    : 'n/a',
);

// ---- 4. 每条尺寸线都算过：全选 ---------------------------------------------

const entityCount = await readEntityCount();
check('读到了图元总数', Number.isFinite(entityCount), `${entityCount}`);

await pressKey('a', 'KeyA', 65, 2); // Ctrl+A 全选
await settle();
const all = await readLabels();
check(
  '全选后每个图元各有一条尺寸标签',
  all.length === entityCount,
  `${all.length} 个标签 / ${entityCount} 个图元`,
);
check(
  '每条标签都有内容且不是占位符',
  all.every((l) => typeof l.text === 'string' && l.text.trim().length > 0 && !l.text.includes('NaN') && !l.text.includes('undefined')),
  all.map((l) => l.text).join(' | ').slice(0, 120),
);

// 标签必须被夹在画布里（clampToView）：不能有半个数字探出去。
const layerW = box.w;
const layerH = box.h;
const outOfBounds = all.filter(
  (l) => l.left < -0.5 || l.top < -0.5 || l.right > layerW + 0.5 || l.bottom > layerH + 0.5,
);
check('所有标签都完整落在画布内（边缘不被裁）', outOfBounds.length === 0, outOfBounds.map((l) => l.text).join(' '));

// 各类图元该出的量都出了：圆要有 R 和 ⌀，圆弧要有弧长，直线要有角度。
const joined = all.map((l) => l.text).join(' | ');
check('圆的标签含半径与直径', /R\s/.test(joined) && /⌀/.test(joined), joined.match(/R [^|]*/)?.[0] ?? '');
check('全选里含角度读数（直线 / 圆弧）', /∠|°/.test(joined));

// ---- 4. 开关闭环 -----------------------------------------------------------

const toggleTitle = await dimsToggleTitle();
check('工具栏上有「尺寸」开关', !!toggleTitle, `${toggleTitle}`);

const shotLive = process.argv.includes('--shot');
const shoot = async (name) => {
  const shot = await send('Page.captureScreenshot', { format: 'png' });
  writeFileSync(name, Buffer.from(shot.data, 'base64'));
  console.log(`  ↳ 已保存 ${name}`);
};
if (shotLive) await shoot('dims-selected.png');

check('关闭前：「尺寸」开关处于开启态', (await evaluate(`(() => {
  const b = [...document.querySelectorAll('.tool-btn[title]')].find(x => x.title.includes('自动尺寸'));
  return b ? b.classList.contains('active') : null;
})()`)) === true);

await clickSel('.tool-btn[title*="自动尺寸"]');
await settle();
check('关闭后：全部尺寸标签消失', (await readLabels()).length === 0, `实测 ${(await readLabels()).length}`);

// 对照：关掉尺寸不该把选中态一起关掉 —— 否则上面那条可能只是「什么都坏了」。
check(
  '（对照）关闭尺寸后选中态仍在（画布未崩）',
  (await evaluate(`!!document.querySelector('canvas.canvas-gl')`)) === true &&
    (await evaluate(`document.querySelectorAll('.dim-layer').length`)) === 1,
);

// 关闭状态下绘制中也不出读数。
await pressKey('l', 'KeyL', 76);
await clickAt(box.x + box.w * 0.35, box.y + box.h * 0.7);
await moveMouse(box.x + box.w * 0.55, box.y + box.h * 0.7);
await settle();
check('关闭后：绘制中也不出读数', (await readLabels()).length === 0, `实测 ${(await readLabels()).length}`);
await pressKey('Escape', 'Escape', 27);
await pressKey('Escape', 'Escape', 27);

// 重新打开 —— 闭环。
await clickSel('.tool-btn[title*="自动尺寸"]');
await pressKey('a', 'KeyA', 65, 2);
await settle();
const back = await readLabels();
check('重新打开后：标签全部回来', back.length > 0, `${back.length} 个`);

// ---- 5. 命令行 DIM ---------------------------------------------------------

await clickSel('.cmd-input');
await send('Input.insertText', { text: 'DIM' });
await sleep(60);
await pressKey('Enter', 'Enter', 13);
await settle();
const afterCmd = await readLabels();
check('命令行 DIM 也能切换（关）', afterCmd.length === 0, `实测 ${afterCmd.length}`);

await clickSel('.cmd-input');
await send('Input.insertText', { text: 'DIM' });
await sleep(60);
await pressKey('Enter', 'Enter', 13);
await settle();
check('命令行 DIM 再切一次（开）', (await readLabels()).length > 0, `${(await readLabels()).length} 个`);

if (shotLive) {
  await clickSel('.cmd-input');
  await pressKey('Escape', 'Escape', 27);
  await evaluate(`document.activeElement && document.activeElement.blur()`);
  // 出一条实时读数再截图，两张图各展示一条来源。
  await pressKey('l', 'KeyL', 76);
  await clickAt(box.x + box.w * 0.3, box.y + box.h * 0.62);
  await moveMouse(box.x + box.w * 0.6, box.y + box.h * 0.34);
  await settle();
  await shoot('dims-live.png');
}

// ---- 6. 控制台 -------------------------------------------------------------

check('全程无 console.error / 未捕获异常', problems.length === 0, problems.slice(0, 3).join(' || '));

// ---------------------------------------------------------------------------

ws.close();
chrome.kill();
try {
  rmSync(profile, { recursive: true, force: true });
} catch {
  /* 临时目录留着也无妨 */
}

if (failures.length) {
  console.error(`\n❌ ${failures.length} 项失败：\n  - ${failures.join('\n  - ')}\n`);
  process.exitCode = 1;
} else {
  console.log('\n✅ 自动尺寸：实时读数、选中尺寸、数值正确性、开关闭环 全部通过\n');
}
