// 渲染循环冒烟测试
//
// 为什么需要它：之前的验证只 `--dump-dom` 检查 DOM 文本，从不驱动 requestAnimationFrame，
// 因此 `SceneBuffer.run()` 里的 `undefined.buffer` 崩溃完全没被发现。
// 本脚本用 CDP 直连无头 Chrome，加载 *生产构建* 的 dist/，然后：
//   1. 等待内核就绪（轮询 window 上的探针）
//   2. 用合成鼠标事件在画布上真实绘制图元（直线 / 圆 / 多段线）
//   3. 让它跑够多帧，捕获期间所有 console 错误与 uncaught exception
//   4. 读取内核跑出的统计值，确认几何真的被 WASM 镶嵌了
//
// 用法：node scripts/smoke-render.mjs [url]

import { spawn } from 'node:child_process';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const CHROME_CANDIDATES = [
  'C:/Program Files/Google/Chrome/Application/chrome.exe',
  'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe',
];

const url = process.argv.slice(2).find((a) => !a.startsWith('--')) ?? 'http://127.0.0.1:5273/';
// Random debug port so concurrent / back-to-back runs cannot collide.
const debugPort = 9300 + Math.floor(Math.random() * 400);
const profile = mkdtempSync(join(tmpdir(), 'unicad-smoke-'));
const chrome = spawn(
  CHROME_CANDIDATES[0],
  [
    '--headless=new',
    '--disable-gpu-sandbox',
    '--enable-unsafe-swiftshader',
    '--use-gl=angle',
    '--use-angle=swiftshader',
    `--remote-debugging-port=${debugPort}`,
    '--no-first-run',
    '--no-default-browser-check',
    `--user-data-dir=${profile}`,
    '--window-size=1440,900',
    url,
  ],
  { stdio: 'ignore' },
);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function targets() {
  const res = await fetch(`http://127.0.0.1:${debugPort}/json/list`);
  return res.json();
}

let ws;
let id = 0;
const pending = new Map();
const consoleErrors = [];
const exceptions = [];

function send(method, params = {}) {
  const msgId = ++id;
  ws.send(JSON.stringify({ id: msgId, method, params }));
  return new Promise((resolve, reject) => pending.set(msgId, { resolve, reject }));
}

async function evaluate(expression) {
  const r = await send('Runtime.evaluate', {
    expression,
    awaitPromise: true,
    returnByValue: true,
  });
  if (r.exceptionDetails) {
    throw new Error(r.exceptionDetails.exception?.description ?? 'eval failed');
  }
  return r.result.value;
}

async function mouse(type, x, y, buttons = 0) {
  await send('Input.dispatchMouseEvent', {
    type,
    x,
    y,
    button: type === 'mouseMoved' ? 'none' : 'left',
    buttons,
    clickCount: type === 'mousePressed' || type === 'mouseReleased' ? 1 : 0,
  });
}

/**
 * 在画布上按下一串点，模拟真实绘制。
 *
 * 每个点都必须「按下 + 松开」成对发送：指针按下状态不变化时，浏览器会把后一
 * 次按下合并掉，工具只收到第一个点，于是永远停在「指定下一点」。
 */
async function drawPath(points) {
  for (const [x, y] of points) {
    await mouse('mouseMoved', x, y, 0);
    await mouse('mousePressed', x, y, 1);
    await mouse('mouseReleased', x, y, 0);
    await sleep(50);
  }
}

/**
 * 点屏幕上那个名为 `label` 的绘图工具按钮。
 *
 * 优先按 `.tool-name` 里的文字**精确**匹配，而不是
 * `button.textContent.includes()` —— 按钮里还带着一个字形，且「圆」是
 * 「圆弧」「椭圆」的子串，用 includes 会点错。
 *
 * 收拢态下绘图工具是纯图标（没有 `.tool-name`），所以回退到按 `title` 前缀
 * 匹配（`title` 是「直线 (L)」）。**测试不应该依赖工具栏当前是哪一档** ——
 * 首次访问在窄窗口下默认就是收拢态，靠文字定位会直接把冒烟测试搞挂。
 */
async function selectTool(label) {
  const ok = await evaluate(`
    (() => {
      const wanted = ${JSON.stringify(label)};
      const byName = [...document.querySelectorAll('.tool-name')]
        .find(x => x.textContent.trim() === wanted);
      const byTitle = [...document.querySelectorAll('.tool-btn[title]')]
        .find(x => x.title.startsWith(wanted + ' ('));
      const b = (byName ?? byTitle)?.closest('button');
      if (b) b.click();
      return !!b;
    })()
  `);
  if (!ok) throw new Error(`找不到绘图工具按钮：${label}`);
  await sleep(150);
}

async function main() {
  // 等待调试端口起来
  let list;
  for (let i = 0; i < 60; i++) {
    try {
      list = await targets();
      if (list.length) break;
    } catch {
      /* 还没起来 */
    }
    await sleep(250);
  }
  if (!list?.length) throw new Error('Chrome 调试端口未就绪');

  const page = list.find((t) => t.type === 'page');
  ws = new WebSocket(page.webSocketDebuggerUrl);
  await new Promise((res, rej) => {
    ws.onopen = res;
    ws.onerror = rej;
  });

  ws.onmessage = (ev) => {
    const msg = JSON.parse(ev.data);
    if (msg.id && pending.has(msg.id)) {
      const { resolve, reject } = pending.get(msg.id);
      pending.delete(msg.id);
      msg.error ? reject(new Error(JSON.stringify(msg.error))) : resolve(msg.result);
      return;
    }
    if (msg.method === 'Runtime.consoleAPICalled' && msg.params.type === 'error') {
      consoleErrors.push(msg.params.args.map((a) => a.value ?? a.description).join(' '));
    }
    if (msg.method === 'Runtime.exceptionThrown') {
      const d = msg.params.exceptionDetails;
      const desc = d.exception?.description ?? d.text;
      // 折叠重复堆栈，避免 249 条同样内容刷屏
      const key = desc.split('\n')[0];
      if (!exceptions.some((e) => e.split('\n')[0] === key)) exceptions.push(desc);
      else exceptions.push(`      (重复) ${key}`);
    }
  };

  await send('Runtime.enable');
  await send('Page.enable');
  await send('Input.setIgnoreEvents', { ignore: false }).catch(() => {});
  await send('Input.setIgnoreInputEvents', { ignore: false });

  // 暴露 encode 结果，方便出错时取证。
  await send('Page.addScriptToEvaluateOnNewDocument', {
    source: `
      window.__unicadProbe = { calls: [], last: null };
      window.addEventListener('error', (e) => {
        window.__unicadProbe.last = {
          message: e.message,
          stack: e.error && e.error.stack,
          at: Date.now(),
        };
      });
    `,
  });

  // 等 body 出现
  for (let i = 0; i < 80; i++) {
    const ok = await evaluate(`!!document.body`);
    if (ok) break;
    await sleep(250);
  }

  // 等内核加载完（生产包首屏 + wasm 实例化）
  for (let i = 0; i < 80; i++) {
    const t = await evaluate(`document.body ? document.body.innerText : ''`);
    if (/WASM/.test(t)) break;
    await sleep(250);
  }

  const kernelText = await evaluate(`
    (() => {
      if (!document.body) return '';
      const m = document.body.innerText.match(/内核[^\\n]*/g);
      return m ? m.join(' | ') : '';
    })()
  `);

  // 画布尺寸与位置
  const box = await evaluate(`
    (() => {
      const c = document.querySelector('canvas');
      if (!c) return null;
      const r = c.getBoundingClientRect();
      return { x: r.x, y: r.y, w: r.width, h: r.height };
    })()
  `);
  if (!box) throw new Error('找不到 canvas');

  const cx = box.x + box.w / 2;
  const cy = box.y + box.h / 2;

  // ---- 真实绘制几组图元 ----
  // 必须先切工具：默认工具是「选择」，直接点不会产生任何图元。
  await selectTool('直线');

  // 1) 直线
  await drawPath([
    [cx - 220, cy - 90],
    [cx + 40, cy - 40],
  ]);

  // 2) 再画一条，制造交点 -> 触发 OSNAP intersection 分支
  await drawPath([
    [cx + 40, cy - 160],
    [cx - 60, cy + 90],
  ]);

  // 3) 切到圆工具：点圆心 + 半径
  await selectTool('圆');
  await drawPath([
    [cx + 150, cy + 40],
    [cx + 230, cy + 40],
  ]);

  // 4) 再画一条直线，确保多帧持续刷新
  await selectTool('直线');
  await drawPath([
    [cx - 180, cy + 120],
    [cx + 220, cy + 150],
  ]);

  // ---- 压力测试：交错触发「事件处理器里的内核查询」与「RAF 里的镶嵌」----
  // 这正是崩溃复现时的条件：snapQuery/pickAll 从 pointer 事件里调内核，
  // 同时 RAF 循环在调 tessellate。若 glue 的 WASM_VECTOR_LEN / bump 分配器
  // 被交错破坏，就会 trap 成 memory access out of bounds。
  for (let round = 0; round < 12; round++) {
    const t = round / 12;
    const px = cx - 260 + t * 520;
    const py = cy - 140 + Math.sin(t * Math.PI * 2) * 120;
    // 高频移动（每个都会触发 computeSnap -> snapQuery）
    await mouse('mouseMoved', px, py, 0);
    await mouse('mouseMoved', px + 3, py + 2, 0);
    // 穿插一次点击，触发 pickAll / 工具放置
    if (round % 3 === 0) {
      await mouse('mousePressed', px, py, 1);
      await mouse('mouseReleased', px, py, 1);
    }
    // 同时逼渲染循环继续跑
    await evaluate(`new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)))`);
  }
  await sleep(200);

  // 让渲染循环跑够多帧（这是上次漏掉的关键一步）
  const frameCount = await evaluate(`
    new Promise((resolve) => {
      let n = 0;
      const t0 = performance.now();
      const tick = () => {
        n++;
        if (performance.now() - t0 > 2500) resolve(n);
        else requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    })
  `);

  // 读取页面统计信息。
  // 注意：这里刻意不只看 DOM 文本 —— 上次只 dump DOM，导致崩溃完全没被发现。
  // 现在同时读取 DOM 上下的真实计数（图元数、渲染顶点数）。
  const stats = await evaluate(`
    (() => {
      const t = document.body ? document.body.innerText : '';
      const grab = (re) => { const m = t.match(re); return m ? m[0].trim() : null; };
      // 找形如「12」紧跟在「图元」标签后的数字
      const ent = t.match(/图元\\s+(\\d+)/);
      return {
        kernel: grab(/内核[^\\n]*/),
        entityLine: grab(/图元\\s+\\d+[^\\n]*/),
        entityCount: ent ? Number(ent[1]) : null,
        vertexLine: grab(/顶点[^\\n]*/),
        degrade: /降级/.test(t),
        logTail: (t.match(/已就绪[^\\n]*|已移动[^\\n]*|选择了[^\\n]*/g) || []).slice(-6),
      };
    })()
  `);

  // 取证：把当前工具、图元类型与数量 dump 出来
  const dump = await evaluate(`
    (() => {
      const btns = [...document.querySelectorAll('button')].map(b => b.textContent.trim()).filter(Boolean);
      const canvases = [...document.querySelectorAll('canvas')].map(c => ({ w: c.width, h: c.height }));
      return { buttons: btns.slice(0, 40), canvases };
    })()
  `);
  console.log('--- 页面取证 ---');
  console.log(JSON.stringify(dump, null, 2));

  await sleep(300);

  const report = {
    url,
    kernelText: kernelText || null,
    frames: frameCount,
    stats,
    consoleErrors,
    exceptions,
  };
  console.log(JSON.stringify(report, null, 2));

  const bad = consoleErrors.length + exceptions.length;
  // 没报错不等于画对了：工具可能一次都没提交（`LineTool` 曾经就是如此 ——
  // 提示一路在走、图元一个没有）。示例图纸自带 8 个图元，所以「没报错 + 图元数
  // 没涨」正是那类故障的指纹。
  const noGeometry = typeof stats.entityCount === 'number' && stats.entityCount <= 8;

  if (bad > 0) {
    console.log(`\n❌ 捕获 ${bad} 条错误`);
  } else if (noGeometry) {
    console.log(`\n❌ 渲染无错误，但合成点击没有产生任何新图元（图元数 ${stats.entityCount}）`);
  } else {
    console.log('\n✅ 渲染循环无错误，且合成交互成功创建了图元');
  }

  ws.close();
  chrome.kill();
  await sleep(300);
  try {
    rmSync(profile, { recursive: true, force: true });
  } catch {
    /* Windows 可能仍锁定 profile，忽略 */
  }
  process.exit(bad === 0 && !noGeometry ? 0 : 1);
}

main().catch(async (err) => {
  console.error('冒烟测试失败：', err.message);
  try {
    ws?.close();
    chrome.kill();
    rmSync(profile, { recursive: true, force: true });
  } catch {
    /* ignore */
  }
  process.exit(2);
});
