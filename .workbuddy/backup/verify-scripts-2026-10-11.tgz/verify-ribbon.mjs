// 顶部工具栏「收拢」验证
//
// 为什么单独一个脚本：收拢是**布局契约**，不是像素问题。要证明的是四件事：
//
//   1. 收拢让出的高度精确等于 62 − 34 = 28px，并且**画布跟着长高**。
//      ResizeObserver 没触发的话画布会保持旧尺寸 —— 顶部留白 or 底部被裁，
//      两种都是「看起来没坏、实际坏了」。
//   2. 收拢没有让任何控件变得不可达：8 个绘图工具、3 个约束 + 栅格、8 个对象
//      捕捉、以及折进下拉的 文件/交换 六个动作，全部仍可一键点到。
//   3. 下拉菜单不被 `overflow-x: auto` 的滚动容器裁掉。
//   4. 状态持久化：刷新后仍是收拢态。否则「每次刷新都弹回来」比不给开关还烦。
//
// 画布是否还画得出东西由 verify:pixels 负责，这里不重复像素解码。
//
// 用法：node scripts/verify-ribbon.mjs [url]

import { spawn } from 'node:child_process';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const CHROME = 'C:/Program Files/Google/Chrome/Application/chrome.exe';
const url = process.argv.slice(2).find((a) => !a.startsWith('--')) ?? 'http://127.0.0.1:5273/';

// 先确认目标真的在服务，否则「工具栏不对」可能只是连错了端口。
try {
  const probe = await fetch(url, { method: 'HEAD' });
  if (!probe.ok) throw new Error(`HTTP ${probe.status}`);
} catch (e) {
  console.error(`❌ 无法访问 ${url}（${e.message}）—— 请先 npm run dev 或 npm run preview 再跑本检查。`);
  process.exit(2);
}

/** CSS 变量里的两档高度；改动 global.css 时必须同步这里。 */
const H_EXPANDED = 62;
const H_COLLAPSED = 34;
const RIBBON_KEY = 'unicad.ui.ribbonCollapsed';
/**
 * 与 `editorStore.RIBBON_AUTO_COLLAPSE_BELOW` 保持一致。
 *
 * 这个数字不能只写在源码里：它必须 ≥ 展开态的实际内容宽，否则会出现
 * 「默认展开、但根本放不下」。下面有一条第 1 节之后的断言专门守这条边界 ——
 * 往工具栏加控件后它会失败，提醒你把这个数一起调上去。
 */
const AUTO_COLLAPSE_BELOW = 2000;

const port = 9800 + Math.floor(Math.random() * 100);
const profile = mkdtempSync(join(tmpdir(), 'unicad-ribbon-'));

const chrome = spawn(
  CHROME,
  [
    '--headless=new',
    '--enable-unsafe-swiftshader',
    '--use-gl=angle',
    '--use-angle=swiftshader',
    `--remote-debugging-port=${port}`,
    '--no-first-run',
    '--no-default-browser-check',
    `--user-data-dir=${profile}`,
    '--window-size=1440,900',
    'about:blank',
  ],
  { stdio: 'ignore' },
);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

let list = null;
for (let i = 0; i < 80; i++) {
  try {
    list = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
    if (list.length) break;
  } catch {
    /* not up yet */
  }
  await sleep(250);
}
const page = list.find((t) => t.type === 'page');
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((res, rej) => {
  ws.onopen = res;
  ws.onerror = rej;
});

let id = 0;
const pending = new Map();
/** 只收 error / exception —— Vite 与 React 会打一堆 info 级噪音。 */
const problems = [];

ws.onmessage = (ev) => {
  const m = JSON.parse(ev.data);
  if (m.id && pending.has(m.id)) {
    const resolve = pending.get(m.id);
    pending.delete(m.id);
    resolve(m.result);
    return;
  }
  if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') {
    problems.push('console.error: ' + m.params.args.map((a) => a.value ?? a.description).join(' '));
  }
  if (m.method === 'Runtime.exceptionThrown') {
    const d = m.params.exceptionDetails;
    problems.push('exception: ' + (d?.exception?.description ?? d?.text));
  }
};

const send = (method, params = {}) => {
  const i = ++id;
  ws.send(JSON.stringify({ id: i, method, params }));
  return new Promise((r) => pending.set(i, r));
};

const evaluate = async (expr) =>
  (await send('Runtime.evaluate', { expression: expr, awaitPromise: true, returnByValue: true }))
    .result?.value;

await send('Runtime.enable');
await send('Page.enable');

const waitForApp = async () => {
  for (let i = 0; i < 80; i++) {
    if (await evaluate(`!!document.querySelector('canvas.canvas-gl')`)) break;
    await sleep(250);
  }
  // 等 wasm 内核就绪 —— 首帧是 TS 回退，两帧之间的尺寸行为不同。
  for (let i = 0; i < 60; i++) {
    const t = (await evaluate(`document.body ? document.body.innerText : ''`)) ?? '';
    if (/WASM|已就绪/.test(t)) break;
    await sleep(250);
  }
  await settle();
};

/** 等两帧，让 React 提交 DOM 变更 + ResizeObserver 的回调跑完。 */
const settle = () =>
  evaluate(
    `new Promise(r => requestAnimationFrame(() => requestAnimationFrame(() => requestAnimationFrame(r))))`,
  );

await send('Page.navigate', { url });
await waitForApp();

// ---------------------------------------------------------------------------
// DOM 探针
// ---------------------------------------------------------------------------

const rectOf = (sel) =>
  evaluate(`(() => {
    const e = document.querySelector(${JSON.stringify(sel)});
    if (!e) return null;
    const b = e.getBoundingClientRect();
    return { x: b.x, y: b.y, w: b.width, h: b.height, left: b.left, top: b.top, right: b.right, bottom: b.bottom };
  })()`);

const countOf = (sel) =>
  evaluate(`document.querySelectorAll(${JSON.stringify(sel)}).length`);

const ribbonInfo = () =>
  evaluate(`(() => {
    const e = document.querySelector('.ribbon');
    if (!e) return null;
    const b = e.getBoundingClientRect();
    return {
      h: +b.height.toFixed(2),
      collapsed: e.classList.contains('collapsed'),
      scrollW: e.scrollWidth,
      clientW: e.clientWidth,
      overflowX: e.scrollWidth > e.clientWidth + 1,
    };
  })()`);

/**
 * 画布容器 + 画布的尺寸三方对照。
 *
 * `hostH` 是 ResizeObserver 观察的那个元素；`cssH` 是画布的 CSS 盒；
 * `pxH/pxW` 是 backing store。三者必须一致（backing store 再乘 dpr）——
 * 只对上一个不算过，历史上有过「CSS 盒与 backing store 差 1px 导致整幅重采样」
 * 的问题。
 */
const canvasInfo = () =>
  evaluate(`(() => {
    const host = document.querySelector('.canvas-host');
    const c = document.querySelector('canvas.canvas-gl');
    if (!host || !c) return null;
    const hb = host.getBoundingClientRect();
    const cb = c.getBoundingClientRect();
    return {
      hostH: +hb.height.toFixed(2),
      hostW: +hb.width.toFixed(2),
      cssH: +cb.height.toFixed(2),
      cssW: +cb.width.toFixed(2),
      pxH: c.height,
      pxW: c.width,
      dpr: window.devicePixelRatio || 1,
    };
  })()`);

const storedFlag = () => evaluate(`window.localStorage.getItem(${JSON.stringify(RIBBON_KEY)})`);

/** 当前高亮的工具按钮标题 —— 用来验证 Escape 没有误伤工具状态。 */
const activeToolTitle = () =>
  evaluate(`(() => {
    const b = document.querySelector('.ribbon .tool-btn.active');
    return b ? b.title : null;
  })()`);

// ---------------------------------------------------------------------------
// 真实输入
// ---------------------------------------------------------------------------

const clickAt = async (x, y) => {
  await send('Input.dispatchMouseEvent', { type: 'mouseMoved', x, y, button: 'none', buttons: 0 });
  await send('Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', buttons: 1, clickCount: 1 });
  await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', buttons: 0, clickCount: 1 });
  await sleep(90);
};

const clickSel = async (sel) => {
  const r = await rectOf(sel);
  if (!r || r.w <= 0 || r.h <= 0) return r;
  await clickAt(r.x + r.w / 2, r.y + r.h / 2);
  return r;
};

const pressKey = async (key, code, vk, modifiers = 0) => {
  await send('Input.dispatchKeyEvent', {
    type: 'rawKeyDown',
    modifiers,
    key,
    code,
    windowsVirtualKeyCode: vk,
    nativeVirtualKeyCode: vk,
  });
  await send('Input.dispatchKeyEvent', {
    type: 'keyUp',
    modifiers,
    key,
    code,
    windowsVirtualKeyCode: vk,
    nativeVirtualKeyCode: vk,
  });
  await sleep(90);
};

// ---------------------------------------------------------------------------
// 断言
// ---------------------------------------------------------------------------

const failures = [];
const check = (name, ok, detail = '') => {
  console.log(`${ok ? '✓' : '✗'} ${name}${detail ? `  — ${detail}` : ''}`);
  if (!ok) failures.push(name);
};
const near = (a, b, tol) => Math.abs(a - b) <= tol;

console.log(`\n目标: ${url}\n`);

/** 视口宽度：展开态的收拢按钮靠 sticky 贴右边缘，必须检查它真的没被推出屏幕。 */
const vpWidth = await evaluate(`window.innerWidth`);

// ---- 0. 全新 profile：自动默认 ---------------------------------------------
//
// 展开态是 ≈1850px 的控件，窄窗口放不下。首次访问（localStorage 为空）应当
// 直接给收拢态，而不是给一条要横向滚动的工具栏。窗口宽度是脚本自己指定的
// （--window-size=1440），所以这条断言是确定的。

const fresh = await ribbonInfo();
check(
  '首次访问：窄窗口自动收拢',
  !!fresh && fresh.collapsed === (vpWidth < AUTO_COLLAPSE_BELOW),
  `视口 ${vpWidth}px → collapsed=${fresh?.collapsed}`,
);

// 后面各段都以「展开态」为起点，所以把状态显式写成展开再刷新 ——
// 否则所有断言都会悄悄依赖窗口宽度。
await evaluate(`window.localStorage.setItem(${JSON.stringify(RIBBON_KEY)}, '0')`);
await send('Page.reload');
await waitForApp();

// ---- 1. 展开态 -------------------------------------------------------------

const r0 = await ribbonInfo();
const v0 = await canvasInfo();

check('展开态：.ribbon 存在', !!r0);
check(`展开态：高度 = ${H_EXPANDED}px`, !!r0 && near(r0.h, H_EXPANDED, 0.5), `实测 ${r0?.h}px`);
check('展开态：无 collapsed class', !!r0 && !r0.collapsed);
check(
  '展开态：6 个分组 + 6 个组标题',
  (await countOf('.ribbon-group')) === 6 && (await countOf('.ribbon-group-label')) === 6,
  `组 ${await countOf('.ribbon-group')} / 标题 ${await countOf('.ribbon-group-label')}`,
);
check('展开态：8 个绘图工具带文字标签', (await countOf('.ribbon .tool-btn .tool-name')) === 8);
const tRect0 = await rectOf('.ribbon-toggle');
check('展开态：收拢按钮有非零尺寸', !!tRect0 && tRect0.w > 0 && tRect0.h > 0);
check(
  '展开态：收拢按钮完整落在视口内（sticky right:0）',
  !!tRect0 && tRect0.left >= -0.5 && tRect0.right <= vpWidth + 0.5,
  tRect0 ? `left ${tRect0.left.toFixed(0)} right ${tRect0.right.toFixed(0)} / 视口宽 ${vpWidth}` : 'n/a',
);
check('展开态：localStorage 记录了显式展开 = "0"', (await storedFlag()) === '0', `= ${await storedFlag()}`);

// 展开态是定高 + overflow-y: hidden 的，第二行不是「挤」而是**看不见** ——
// 连组标题一起被裁掉。所以这里不是排版偏好检查，是可见性检查。
const clipInfo = await evaluate(`(() => {
  const rb = document.querySelector('.ribbon');
  const rr = rb.getBoundingClientRect();
  const clipped = [];
  for (const el of document.querySelectorAll('.ribbon-group-label, .ribbon-group-body .tool-btn, .ribbon-toggle')) {
    const b = el.getBoundingClientRect();
    if (b.bottom > rr.bottom + 0.5 || b.top < rr.top - 0.5) {
      clipped.push((el.textContent || el.title || '?').trim().slice(0, 10));
    }
  }
  return { clipped, scrollW: rb.scrollWidth, clientW: rb.clientWidth };
})()`);
check(
  '展开态：组标题 / 按钮未被定高栏纵向裁掉',
  clipInfo.clipped.length === 0,
  clipInfo.clipped.length
    ? `被裁 ${clipInfo.clipped.length} 个: ${clipInfo.clipped.slice(0, 5).join(' ')}`
    : `横向 ${clipInfo.scrollW}px / 可视 ${clipInfo.clientW}px`,
);

const rowTops = await evaluate(
  `Array.from(new Set(Array.from(document.querySelectorAll('.ribbon .osnap-row > .tool-btn')).map(b => Math.round(b.getBoundingClientRect().top))))`,
);
check('展开态：约束 + 捕捉开关排成单行', rowTops.length === 1, `top 值 ${rowTops.join(', ')}`);

// 自动收拢阈值必须盖得住展开态的实际内容宽 —— 否则「默认展开」的判定会在某个
// 窗口宽度区间里给出一个根本装不下的工具栏。往工具栏加控件后这条会红。
check(
  '自动收拢阈值 ≥ 展开态内容宽（不会出现「默认展开但放不下」）',
  AUTO_COLLAPSE_BELOW >= clipInfo.scrollW,
  `阈值 ${AUTO_COLLAPSE_BELOW} vs 内容 ${clipInfo.scrollW}px`,
);

// ---- 2. 收拢 --------------------------------------------------------------

const toggleRect = await clickSel('.ribbon-toggle');
check('收拢按钮可点击（有非零尺寸）', !!toggleRect && toggleRect.w > 0 && toggleRect.h > 0);

const r1 = await ribbonInfo();
const v1 = await canvasInfo();

check(`收拢后：高度 = ${H_COLLAPSED}px`, !!r1 && near(r1.h, H_COLLAPSED, 0.5), `实测 ${r1?.h}px`);
check('收拢后：带 collapsed class', !!r1 && r1.collapsed);
check('收拢后：写入 localStorage = "1"', (await storedFlag()) === '1', `= ${await storedFlag()}`);

const gained = v1 && v0 ? +(v1.hostH - v0.hostH).toFixed(2) : NaN;
check(
  `收拢后：画布长高 ${H_EXPANDED - H_COLLAPSED}px（ResizeObserver 生效）`,
  near(gained, H_EXPANDED - H_COLLAPSED, 0.6),
  `实测 ${gained}px`,
);
check(
  '收拢后：画布 CSS 盒 = 容器高度',
  !!v1 && near(v1.cssH, v1.hostH, 0.6),
  `css ${v1?.cssH} vs host ${v1?.hostH}`,
);
check(
  '收拢后：backing store = CSS 盒 × dpr',
  !!v1 && near(v1.pxH, v1.cssH * v1.dpr, 1.5) && near(v1.pxW, v1.cssW * v1.dpr, 1.5),
  `${v1?.pxW}×${v1?.pxH} vs ${v1?.cssW}×${v1?.cssH} @${v1?.dpr}`,
);

// ---- 3. 收拢态的可达性 ------------------------------------------------------

const iconCount = await countOf('.ribbon.collapsed .tool-btn.icon');
check('收拢后：8 工具 + 撤销/重做/删除 = 11 个图标按钮', iconCount === 11, `实测 ${iconCount}`);

const toolTitles = await evaluate(
  `Array.from(document.querySelectorAll('.ribbon.collapsed .tool-btn.icon')).map(b => b.title).filter(t => /\\((SEL|L|PL|REC|C|A|EL|DI)\\)/.test(t))`,
);
check(
  '收拢后：8 个绘图工具全部带 title（图标无文字，title 就是唯一线索）',
  Array.isArray(toolTitles) && toolTitles.length === 8,
  (toolTitles ?? []).join(' | '),
);

const rowText = (await evaluate(`document.querySelector('.ribbon.collapsed')?.innerText ?? ''`)) ?? '';
const wants = ['文件', '正交', '极轴', '捕捉', '栅格', '端点', '中点', '圆心', '象限点', '垂足', '交点', '切点', '最近点', '缩放范围'];
const missing = wants.filter((w) => !rowText.includes(w));
check('收拢后：约束/栅格/8 个捕捉/缩放范围 文案齐全', missing.length === 0, missing.length ? `缺 ${missing.join(' ')}` : `${wants.length} 项`);

const osnapTitled = await countOf('.ribbon.collapsed .tool-btn[title^="对象捕捉"]');
check('收拢后：8 个对象捕捉开关可按 title 定位', osnapTitled === 8, `实测 ${osnapTitled}`);

// 收拢的全部意义就是「一行放得下」。放不下的话它只是换了个方式溢出，
// 还不如不收 —— 脚本固定 --window-size=1440，所以这条断言是确定的。
check(
  '收拢后：单行内容放得下，无需横向滚动',
  !!r1 && r1.scrollW <= r1.clientW + 1,
  `内容 ${r1?.scrollW}px / 可视 ${r1?.clientW}px`,
);

const collapsedClip = await evaluate(`(() => {
  const bar = document.querySelector('.ribbon.collapsed');
  const br = bar.getBoundingClientRect();
  const bad = [];
  for (const el of bar.children) {
    const b = el.getBoundingClientRect();
    if (b.bottom > br.bottom + 0.5 || b.top < br.top - 0.5) bad.push((el.textContent || el.title || '?').trim().slice(0, 8));
  }
  return bad;
})()`);
check('收拢后：无子元素被 34px 高度裁掉', collapsedClip.length === 0, collapsedClip.join(' '));

// ---- 4. 下拉菜单不被裁切 ----------------------------------------------------

const fileBtn = await clickSel('.ribbon.collapsed .tool-btn[aria-haspopup="menu"]');
check('收拢后：文件下拉按钮存在', !!fileBtn && fileBtn.w > 0);

const menu = await rectOf('.ribbon-menu');
const menuItems = await countOf('.ribbon-menu-item');
check('点开下拉：菜单已渲染', !!menu);
check('点开下拉：菜单有非零尺寸', !!menu && menu.w > 0 && menu.h > 0, menu ? `${menu.w}×${menu.h}` : 'n/a');

const vp = await evaluate(`({ w: window.innerWidth, h: window.innerHeight })`);
check(
  '点开下拉：菜单完整落在视口内（没被 overflow 裁掉）',
  !!menu && menu.left >= 0 && menu.top >= 0 && menu.right <= vp.w && menu.bottom <= vp.h,
  menu ? `left ${menu.left.toFixed(0)} right ${menu.right.toFixed(0)} bottom ${menu.bottom.toFixed(0)} / vp ${vp.w}×${vp.h}` : 'n/a',
);
check('点开下拉：6 个菜单项（新建/打开/保存 + 3 个交换）', menuItems === 6, `实测 ${menuItems}`);

const menuText = (await evaluate(`document.querySelector('.ribbon-menu')?.innerText ?? ''`)) ?? '';
const wantItems = ['新建', '打开', '保存', '导入 DXF', '导出 DXF', '导出 PNG'];
const missingItems = wantItems.filter((w) => !menuText.includes(w));
check('点开下拉：六个动作文案齐全', missingItems.length === 0, missingItems.length ? `缺 ${missingItems.join(' ')}` : '');

// ---- 5. Escape 只关菜单，不误伤工具状态 -------------------------------------

await clickSel('.ribbon.collapsed .tool-btn[title^="直线"]');
const toolBefore = await activeToolTitle();
check('收拢态下可切换工具（点直线 → 高亮）', !!toolBefore && toolBefore.startsWith('直线'), `${toolBefore}`);

// 上面点工具本身就把菜单关掉了（外部点击），所以必须重新打开 ——
// 否则这一段的 Escape 压根没经过菜单，断言会恒真。
await clickSel('.ribbon.collapsed .tool-btn[aria-haspopup="menu"]');
check('（前置）菜单已重新打开', (await countOf('.ribbon-menu')) === 1);

await pressKey('Escape', 'Escape', 27);
const toolAfterMenuEscape = await activeToolTitle();
check(
  '菜单开着时按 Escape：只关菜单，工具保持直线',
  !!toolAfterMenuEscape && toolAfterMenuEscape.startsWith('直线'),
  `${toolAfterMenuEscape}`,
);
check('菜单开着时按 Escape：菜单已关闭', (await countOf('.ribbon-menu')) === 0);

// 对照组：菜单关闭时 Escape **应该**回到选择工具 —— 否则上面那条断言可能恒真。
await pressKey('Escape', 'Escape', 27);
const toolAfterPlainEscape = await activeToolTitle();
check(
  '（对照组）菜单关闭时按 Escape：回到选择工具',
  !!toolAfterPlainEscape && toolAfterPlainEscape.startsWith('选择'),
  `${toolAfterPlainEscape}`,
);

// ---- 6. 点击外部关闭 -------------------------------------------------------

await clickSel('.ribbon.collapsed .tool-btn[aria-haspopup="menu"]');
check('再次点文件：菜单重新打开', (await countOf('.ribbon-menu')) === 1);
const canvasRect = await rectOf('canvas.canvas-gl');
await clickAt(canvasRect.x + canvasRect.w / 2, canvasRect.y + canvasRect.h / 2);
check('点菜单外部：菜单关闭', (await countOf('.ribbon-menu')) === 0);

// ---- 7. 持久化 -------------------------------------------------------------

await send('Page.reload');
await waitForApp();
const r2 = await ribbonInfo();
check('刷新后：仍是收拢态', !!r2 && r2.collapsed, `collapsed=${r2?.collapsed}`);
check(`刷新后：高度仍为 ${H_COLLAPSED}px`, !!r2 && near(r2.h, H_COLLAPSED, 0.5), `实测 ${r2?.h}px`);

// ---- 8. Ctrl+F1 展开回去 ---------------------------------------------------

await pressKey('F1', 'F1', 112, 2);
const r3 = await ribbonInfo();
check(`Ctrl+F1：展开回 ${H_EXPANDED}px`, !!r3 && !r3.collapsed && near(r3.h, H_EXPANDED, 0.5), `高度 ${r3?.h}`);
check('Ctrl+F1：localStorage 写回 "0"', (await storedFlag()) === '0', `= ${await storedFlag()}`);

await send('Page.reload');
await waitForApp();
const r4 = await ribbonInfo();
check('再次刷新：回到展开态（标志位双向都记得住）', !!r4 && !r4.collapsed, `collapsed=${r4?.collapsed}`);

// ---- 9. 控制台 -------------------------------------------------------------

check('全程无 console.error / 未捕获异常', problems.length === 0, problems.slice(0, 3).join(' || '));

// ---- 10. 出图（给人看的，不做断言）------------------------------------------

if (process.argv.includes('--shot')) {
  const shoot = async (name) => {
    const shot = await send('Page.captureScreenshot', { format: 'png' });
    writeFileSync(name, Buffer.from(shot.data, 'base64'));
    console.log(`  ↳ 已保存 ${name}`);
  };
  await clickSel('.ribbon-toggle');
  await shoot('ribbon-collapsed.png');
  await clickSel('.ribbon.collapsed .tool-btn[aria-haspopup="menu"]');
  await shoot('ribbon-menu.png');
  await pressKey('Escape', 'Escape', 27);
  await pressKey('F1', 'F1', 112, 2);
  await shoot('ribbon-expanded.png');
}

// ---------------------------------------------------------------------------

ws.close();
chrome.kill();
try {
  rmSync(profile, { recursive: true, force: true });
} catch {
  /* Windows 偶尔锁文件，临时目录留着也无妨 */
}

if (failures.length) {
  console.error(`\n❌ ${failures.length} 项失败：\n  - ${failures.join('\n  - ')}\n`);
  process.exitCode = 1;
} else {
  console.log('\n✅ 顶部工具栏收拢：布局、可达性、菜单裁切、持久化 全部通过\n');
}
