// 画布像素验证 —— 确认「真的画出了东西」，而不只是「没有报错」
//
// 为什么需要它：此前的 verify:render / verify:gl 都只检查 console 错误与
// 缓冲越界。如果渲染器**静默跳过**了所有上传，两者都会显示"全部通过"，
// 而画布其实一片空白。这个脚本直接读合成后的画面像素。
//
// 同时挂钩 bufferData / bufferSubData，验证「分配了 N 次、写入了几次」——
// 若出现「分配了但一次都没写入」，即说明上传被中途跳过。
//
// 用法：node scripts/verify-canvas-pixels.mjs [url] [--shot] [--full] [--runs] [--select-all]
//   [--zoom=x,y,w,h[,f]]   裁剪并最近邻放大存成 canvas-zoom.png（看描边边缘）
//   [--ring=cx,cy,r]       沿半径 r 的圆环采样描边宽度，输出分布（查周期性粗细不均）
//   [--probe=ax,ay,bx,by]  沿一条直线测法线方向宽度
//
//   [--linestyle=NAME]     把本次划出的那条线设成该线型（continuous/dashed/
//                          dotted/dashdot/center/hidden），并对墨迹做游程分析：
//                          虚线必须量出**周期性的空档**，且空档+实段的周期等于
//                          图案的屏幕像素周期；实线必须一个空档都没有。
//
// 坐标优先用**模型坐标**，因为它与画布尺寸解耦：
//   [--ring-model=cx,cy,r] 同上，但给的是模型坐标（经 window.__unicadView 换算）
//   [--probe=auto]         测本次合成交互真正画出来的那条线
// 屏幕坐标是画布尺寸的函数 —— 工具栏收拢一次就差 28px，取景随之改变，
// 硬编码的圆心量的就不是那个圆了，而结果会**伪装成描边断续**。

import { spawn } from 'node:child_process';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { deflateSync, inflateSync } from 'node:zlib';

const CHROME = 'C:/Program Files/Google/Chrome/Application/chrome.exe';
// 取第一个非 `--flag` 参数作为 URL，这样 `--shot` 放在前面也不会被当成地址。
const url = process.argv.slice(2).find((a) => !a.startsWith('--')) ?? 'http://127.0.0.1:5273/';
const wantShot = process.argv.includes('--shot');

/**
 * 给本次划出的那条线指定线型，然后用像素证明它**真的**变了。
 *
 * 为什么必须走到像素这一层：线型是个纯视觉参数。把它写进实体的 `lineStyle`
 * 字段、甚至让着色器编译通过、画面里那条线看起来「还是线」—— 每一步都可以
 * 全绿而实际什么都没发生（`RenderStyle.dash` 之前就是这样：算出来了，没人读）。
 * 唯一能证伪的观察量是「沿这条线测出来的描边墨迹，出现了周期性的空档，而且
 * 空档周期等于图案的屏幕像素周期」。
 */
const lineStyleArg =
  process.argv.find((a) => a.startsWith('--linestyle='))?.slice('--linestyle='.length) ?? null;

// 先确认目标真的在服务，否则「画布空白」可能只是连错了端口。
try {
  const probe = await fetch(url, { method: 'HEAD' });
  if (!probe.ok) throw new Error(`HTTP ${probe.status}`);
} catch (e) {
  console.error(`❌ 无法访问 ${url}（${e.message}）—— 请先 npm run dev 或 npm run preview 再跑本检查。`);
  process.exit(2);
}
/** 截整页而不是只截画布区域 —— 排查「工具没选中 / 图元没建成」时用。 */
const wantFull = process.argv.includes('--full');
/** 打印穿过画布中心的行/列亮暗游程 —— 判断描边是连续还是断裂。 */
const wantRuns = process.argv.includes('--runs');
/**
 * 截图前先「全选」。
 *
 * 用来点亮选中态与夹点：夹点走的是 `drawPoints` 的点精灵路径（`gl_PointSize`），
 * 和直线是完全不同的管线，那条路径曾经因为属性没绑定而退化成单像素点。
 */
const wantSelectAll = process.argv.includes('--select-all');
/**
 * 描边连续性断言（由 --ring / --probe 触发）。
 *
 * 这是本脚本最贵的一课换来的：曲线曾经被渲染成一串虚线 —— 每个线段的四边形
 * 只覆盖了它的**后半边**（两个三角形沿不同对角线剖分），缺口周期性出现、
 * 宽度还不小，但 console 干净、图元数正确、亮点落点也全对。只有沿法线量
 * 描边宽度才能发现「有的地方宽度是 0」。
 */
let ringBroken = false;
let probeBroken = false;
/** 线型游程分析结果（`--linestyle` + `--probe` 同时给出时才非空）。 */
let dashResult = null;
const port = 9900 + Math.floor(Math.random() * 100);
const profile = mkdtempSync(join(tmpdir(), 'unicad-px-'));

const chrome = spawn(
  CHROME,
  [
    '--headless=new',
    '--enable-unsafe-swiftshader',
    '--use-gl=angle',
    '--use-angle=swiftshader',
    `--remote-debugging-port=${port}`,
    '--no-first-run',
    '--no-default-browser-check',
    `--user-data-dir=${profile}`,
    '--window-size=1440,900',
    'about:blank',
  ],
  { stdio: 'ignore' },
);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** 最小 PNG 解码器（8-bit，RGB/RGBA/Gray，全部 5 种 filter）。 */
function decodePNG(buf) {
  if (buf.readUInt32BE(0) !== 0x89504e47) throw new Error('不是 PNG');
  let pos = 8;
  let width = 0;
  let height = 0;
  let bitDepth = 0;
  let colorType = 0;
  const idat = [];
  while (pos + 8 <= buf.length) {
    const len = buf.readUInt32BE(pos);
    const type = buf.toString('ascii', pos + 4, pos + 8);
    const data = buf.subarray(pos + 8, pos + 8 + len);
    if (type === 'IHDR') {
      width = data.readUInt32BE(0);
      height = data.readUInt32BE(4);
      bitDepth = data[8];
      colorType = data[9];
    } else if (type === 'IDAT') {
      idat.push(data);
    } else if (type === 'IEND') {
      break;
    }
    pos += 12 + len;
  }
  const channels = colorType === 6 ? 4 : colorType === 2 ? 3 : colorType === 0 ? 1 : 0;
  if (!channels || bitDepth !== 8) {
    throw new Error(`不支持的 PNG: colorType=${colorType} bitDepth=${bitDepth}`);
  }
  const raw = inflateSync(Buffer.concat(idat));
  const stride = width * channels;
  const out = Buffer.alloc(height * stride);
  let prev = Buffer.alloc(stride);
  for (let y = 0; y < height; y++) {
    const base = y * (stride + 1);
    const filter = raw[base];
    const cur = Buffer.from(raw.subarray(base + 1, base + 1 + stride));
    for (let i = 0; i < stride; i++) {
      const a = i >= channels ? cur[i - channels] : 0;
      const b = prev[i];
      const c = i >= channels ? prev[i - channels] : 0;
      switch (filter) {
        case 0:
          break;
        case 1:
          cur[i] = (cur[i] + a) & 0xff;
          break;
        case 2:
          cur[i] = (cur[i] + b) & 0xff;
          break;
        case 3:
          cur[i] = (cur[i] + ((a + b) >> 1)) & 0xff;
          break;
        case 4: {
          const p = a + b - c;
          const pa = Math.abs(p - a);
          const pb = Math.abs(p - b);
          const pc = Math.abs(p - c);
          const pr = pa <= pb && pa <= pc ? a : pb <= pc ? b : c;
          cur[i] = (cur[i] + pr) & 0xff;
          break;
        }
        default:
          throw new Error(`未知 PNG filter ${filter}`);
      }
    }
    cur.copy(out, y * stride);
    prev = cur;
  }
  return { width, height, channels, data: out };
}

// ---- PNG 编码 / 裁剪 / 最近邻放大 ------------------------------------------
//
// 为什么需要：判断「描边粗细是否均匀」用肉眼看原图是没用的 —— 一条 1.4 px 的
// 斜线在 100% 缩放下各种抗锯齿混在一起，看起来都一样。必须把局部放大到 6~8 倍
// 再看边缘，才能区分「真的断开了」和「只是抗锯齿」。

let crcTable = null;
function crc32(buf) {
  if (!crcTable) {
    crcTable = new Int32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      crcTable[n] = c;
    }
  }
  let c = -1;
  for (let i = 0; i < buf.length; i++) c = crcTable[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ -1) >>> 0;
}

function pngChunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const body = Buffer.concat([Buffer.from(type, 'ascii'), data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(body), 0);
  return Buffer.concat([len, body, crc]);
}

/** 统一输出 8-bit RGBA（decodePNG 可能给的是 RGB / Gray）。 */
function encodePNG(img) {
  const { width, height, channels, data } = img;
  const stride = width * 4;
  const raw = Buffer.alloc(height * (stride + 1));
  for (let y = 0; y < height; y++) {
    const row = y * (stride + 1);
    raw[row] = 0; // filter: none
    for (let x = 0; x < width; x++) {
      const s = (y * width + x) * channels;
      const d = row + 1 + x * 4;
      if (channels >= 3) {
        raw[d] = data[s];
        raw[d + 1] = data[s + 1];
        raw[d + 2] = data[s + 2];
        raw[d + 3] = channels === 4 ? data[s + 3] : 255;
      } else {
        raw[d] = raw[d + 1] = raw[d + 2] = data[s];
        raw[d + 3] = 255;
      }
    }
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // colour type: RGBA
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    pngChunk('IHDR', ihdr),
    pngChunk('IDAT', deflateSync(raw)),
    pngChunk('IEND', Buffer.alloc(0)),
  ]);
}

function cropImg(img, x0, y0, w, h) {
  const { width, height, channels } = img;
  const out = Buffer.alloc(w * h * channels);
  for (let y = 0; y < h; y++) {
    const sy = y0 + y;
    if (sy < 0 || sy >= height) continue;
    for (let x = 0; x < w; x++) {
      const sx = x0 + x;
      if (sx < 0 || sx >= width) continue;
      const s = (sy * width + sx) * channels;
      const d = (y * w + x) * channels;
      for (let c = 0; c < channels; c++) out[d + c] = img.data[s + c];
    }
  }
  return { width: w, height: h, channels, data: out };
}

/** 最近邻放大 —— 故意不做插值，插值会把「有没有像素」这件事糊掉。 */
function scaleNearest(img, f) {
  const { width, height, channels, data } = img;
  const w = width * f;
  const h = height * f;
  const out = Buffer.alloc(w * h * channels);
  for (let y = 0; y < h; y++) {
    const sy = Math.floor(y / f);
    for (let x = 0; x < w; x++) {
      const sx = Math.floor(x / f);
      const s = (sy * width + sx) * channels;
      const d = (y * w + x) * channels;
      for (let c = 0; c < channels; c++) out[d + c] = data[s + c];
    }
  }
  return { width: w, height: h, channels, data: out };
}

/**
 * 双线性亮度取样器。
 *
 * 必须双线性：沿法线以 0.2 px 步长积分 50 个采样点时，若用最近邻取整，每个采样点
 * 的误差最大 1 个像素的亮度，累加出来的「宽度」会自带 ±1 px 的抖动 —— 那足以把
 * 真实的均匀描边伪装成周期性粗细不均，也能把真实的粗细不均伪装成量化噪声。
 */
function makeLumSampler(img, bgLum = 22) {
  const { width, height, channels, data } = img;
  const px = (x, y) => {
    const xi = Math.max(0, Math.min(width - 1, Math.floor(x)));
    const yi = Math.max(0, Math.min(height - 1, Math.floor(y)));
    const o = (yi * width + xi) * channels;
    return 0.299 * data[o] + 0.587 * data[o + 1] + 0.114 * data[o + 2];
  };
  return (x, y) => {
    const x0 = Math.floor(x);
    const y0 = Math.floor(y);
    const fx = x - x0;
    const fy = y - y0;
    const a = px(x0, y0);
    const b = px(x0 + 1, y0);
    const c = px(x0, y0 + 1);
    const d = px(x0 + 1, y0 + 1);
    const v = a * (1 - fx) * (1 - fy) + b * fx * (1 - fy) + c * (1 - fx) * fy + d * fx * fy;
    return Number.isFinite(v) ? v : bgLum;
  };
}

/**
 * 沿一条**直线**测垂直方向的描边宽度。
 *
 * 和 `ringProfile` 的区别很重要：圆环剖面沿射线积分，当描边不垂直于射线时测到的
 * 是「径向投影宽度」而非真实宽度，45° 处会虚高 1.41 倍 —— 那会伪造出周期性波动。
 * 直线探针在每一点都沿**该点处的法线**积分，测的才是真正的描边宽度。
 *
 * 于是它成了判断「是接缝问题还是别的问题」的对照组：直线只有一个线段、没有接缝，
 * 若直线宽度也有波动，问题就不在接缝上。
 */
function segmentProfile(img, ax, ay, bx, by, opts = {}) {
  const { samples = 240, band = 5, step = 0.2, bgLum = 22, lineLum = 232 } = opts;
  const lumAt = makeLumSampler(img, bgLum);
  const dx = bx - ax;
  const dy = by - ay;
  const len = Math.hypot(dx, dy);
  const ux = dx / len;
  const uy = dy / len;
  // 法线（屏幕 y 向下）
  const nx = -uy;
  const ny = ux;
  const out = [];
  for (let i = 0; i <= samples; i++) {
    const t = i / samples;
    const cx = ax + dx * t;
    const cy = ay + dy * t;
    let ink = 0;
    for (let d = -band; d <= band; d += step) {
      const cov = (lumAt(cx + nx * d, cy + ny * d) - bgLum) / (lineLum - bgLum);
      if (cov > 0) ink += Math.min(cov, 1) * step;
    }
    out.push({ t, width: ink });
  }
  const w = out.map((s) => s.width);
  const mean = w.reduce((s, v) => s + v, 0) / w.length;
  const varr = w.reduce((s, v) => s + (v - mean) * (v - mean), 0) / w.length;
  return { samples: out, mean, min: Math.min(...w), max: Math.max(...w), std: Math.sqrt(varr) };
}

/**
 * 统计背景占比、颜色种类，并顺便收集「亮像素」的坐标。
 *
 * 亮像素（亮度 > 90）不可能是栅格线 —— 栅格用的是 #1e2228 / #2c313a，
 * 亮度都在 40 以下。所以亮像素只可能来自实体描边、坐标轴与十字准线。
 */
function analyse(img, bg) {
  const { width, height, channels, data } = img;
  const counts = new Map();
  let nonBg = 0;
  let bright = 0;
  const brightPoints = [];
  let minX = width;
  let minY = height;
  let maxX = -1;
  let maxY = -1;
  const total = width * height;
  for (let i = 0; i < total; i++) {
    const o = i * channels;
    const r = data[o];
    const g = data[o + 1];
    const b = data[o + 2];
    const key = (r << 16) | (g << 8) | b;
    counts.set(key, (counts.get(key) ?? 0) + 1);
    if (Math.abs(r - bg[0]) + Math.abs(g - bg[1]) + Math.abs(b - bg[2]) > 6) nonBg++;
    const lum = 0.299 * r + 0.587 * g + 0.114 * b;
    if (lum > 90) {
      bright++;
      const x = i % width;
      const y = (i / width) | 0;
      brightPoints.push(x, y);
      if (x < minX) minX = x;
      if (x > maxX) maxX = x;
      if (y < minY) minY = y;
      if (y > maxY) maxY = y;
    }
  }
  return {
    width,
    height,
    colours: counts.size,
    nonBgRatio: nonBg / total,
    brightRatio: bright / total,
    brightPoints,
    brightBox: maxX < 0 ? null : { minX, minY, maxX, maxY },
    topColours: [...counts.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 8)
      .map(([k, n]) => ({
        hex: '#' + k.toString(16).padStart(6, '0'),
        count: n,
      })),
  };
}

/**
 * 沿一条扫描线输出「亮游程 / 暗游程」的长度序列。
 *
 * 用来回答一个肉眼不可靠的问题：一条描边是连续的，还是断成一串短划？
 * 截图在预览里常被缩放显示，缩放后细线看着就像虚线，所以必须按像素量。
 */
function scanRuns(img, axis, index, from, to, threshold = 90) {
  const { width, channels, data } = img;
  const out = [];
  let cur = null;
  for (let p = from; p < to; p++) {
    const x = axis === 'x' ? p : index;
    const y = axis === 'x' ? index : p;
    const o = (y * width + x) * channels;
    const lum = 0.299 * data[o] + 0.587 * data[o + 1] + 0.114 * data[o + 2];
    const on = lum > threshold;
    if (!cur) cur = { on, len: 1, start: from };
    else if (cur.on === on) cur.len++;
    else {
      out.push(cur);
      cur = { on, len: 1, start: p };
    }
  }
  if (cur) out.push(cur);
  return out;
}

function formatRuns(runs) {
  return runs.map((r) => `${r.on ? '亮' : '暗'}${r.len}`).join(' ');
}

/**
 * 沿一条圆环测量**局部描边宽度**，返回按角度采样的亚像素宽度序列。
 *
 * 为什么需要它：描边是按「每段一个矩形」拼出来的，段与段在连接处的法线方向
 * 不同。若两条线段各自成一个矩形而不做接缝处理，接缝外侧会留楔形缺口、
 * 内侧会互相重叠 —— 抗锯齿的边缘像素被混合两次，于是接缝处看着比段中间更粗。
 * 只在屏幕上量一圈的宽度分布，才能把这种「周期性粗细不均」和随机锯齿区分开。
 *
 * 宽度用**覆盖率积分**估：把每个像素的亮度归一化成 [0,1] 覆盖度，沿射线按
 * `step` 累加，得到亚像素级的宽度，而不是整数像素个数。
 */
function ringProfile(img, cx, cy, r, opts = {}) {
  const { samples = 720, band = 6, step = 0.25, bgLum = 22, lineLum = 232 } = opts;
  const lumAt = makeLumSampler(img, bgLum);
  const out = [];
  for (let i = 0; i < samples; i++) {
    const a = (i / samples) * Math.PI * 2;
    const ux = Math.cos(a);
    const uy = Math.sin(a);
    let ink = 0;
    for (let d = r - band; d <= r + band; d += step) {
      const coverage = (lumAt(cx + ux * d, cy + uy * d) - bgLum) / (lineLum - bgLum);
      if (coverage > 0) ink += Math.min(coverage, 1) * step;
    }
    out.push({ deg: (a * 180) / Math.PI, width: ink });
  }
  const w = out.map((s) => s.width);
  const mean = w.reduce((s, v) => s + v, 0) / w.length;
  const varr = w.reduce((s, v) => s + (v - mean) * (v - mean), 0) / w.length;
  return {
    samples: out,
    mean,
    min: Math.min(...w),
    max: Math.max(...w),
    std: Math.sqrt(varr),
  };
}

/**
 * 有多少个亮点落在给定线段的 `tol` 像素内。
 *
 * 这是本脚本最关键的断言：它检查的是「几何画在了它该在的地方」，而不只是
 * 「画面上有东西」。着色器把模型坐标喂错空间时（曾经把裁剪矩阵当成像素矩阵
 * 用），所有顶点会挤到一个角上 —— 那种情况下栅格还在、像素占比也不低，
 * 只有把线和鼠标点击位置比对才能发现。
 */
function segmentHits(points, ax, ay, bx, by, tol) {
  const dx = bx - ax;
  const dy = by - ay;
  const len2 = dx * dx + dy * dy;
  let hits = 0;
  for (let i = 0; i < points.length; i += 2) {
    const px = points[i];
    const py = points[i + 1];
    let t = len2 > 0 ? ((px - ax) * dx + (py - ay) * dy) / len2 : 0;
    t = Math.max(0, Math.min(1, t));
    const qx = ax + t * dx;
    const qy = ay + t * dy;
    if (Math.hypot(px - qx, py - qy) <= tol) hits++;
  }
  return hits;
}

let list;
for (let i = 0; i < 80; i++) {
  try {
    list = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
    if (list.length) break;
  } catch {
    /* not up */
  }
  await sleep(250);
}
const page = list.find((t) => t.type === 'page');
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((res, rej) => {
  ws.onopen = res;
  ws.onerror = rej;
});

let id = 0;
const pending = new Map();
const consoleMsgs = [];
ws.onmessage = (ev) => {
  const m = JSON.parse(ev.data);
  if (m.id && pending.has(m.id)) {
    const { resolve } = pending.get(m.id);
    pending.delete(m.id);
    resolve(m.result);
    return;
  }
  if (m.method === 'Runtime.consoleAPICalled') {
    consoleMsgs.push(
      m.params.type + ': ' + m.params.args.map((a) => a.value ?? a.description).join(' '),
    );
  }
};
const send = (method, params = {}) => {
  const i = ++id;
  ws.send(JSON.stringify({ id: i, method, params }));
  return new Promise((r) => pending.set(i, { resolve: r }));
};
const evaluate = async (expr) =>
  (await send('Runtime.evaluate', { expression: expr, awaitPromise: true, returnByValue: true }))
    .result?.value;

await send('Runtime.enable');
await send('Page.enable');

await send('Page.addScriptToEvaluateOnNewDocument', {
  source: `
    (() => {
      const s = {
        bufferData: 0, bufferSubData: 0,
        buffersAllocated: 0, buffersWritten: 0,
        skippedAfterAlloc: 0,
      };
      Object.defineProperty(window, '__glUp', { value: s });
      // 顶点流抓取：只留最近 60 次「长度 >= 40 的 Float32 写入」。用来核对
      // 真实上传到 GPU 的坐标，而不是猜渲染器应该写什么。
      const verts = [];
      Object.defineProperty(window, '__glVerts', { value: verts });
      const patch = (Ctor) => {
        if (!Ctor || !Ctor.prototype || !Ctor.prototype.bufferSubData) return;
        const proto = Ctor.prototype;
        const origData = proto.bufferData;
        proto.bufferData = function () {
          s.bufferData++;
          if (typeof arguments[1] === 'number') s.buffersAllocated++;
          return origData.apply(this, arguments);
        };
        const origSub = proto.bufferSubData;
        proto.bufferSubData = function (target, dstByteOffset, srcData, srcOffset, length) {
          s.bufferSubData++;
          s.buffersWritten++;
          if (srcData instanceof Float32Array && length >= 40) {
            const from = srcOffset || 0;
            const win = Array.from(srcData.slice(from, from + Math.min(length, 1200)));
            verts.push({ off: dstByteOffset, from: from, count: length, head: win });
            if (verts.length > 24) verts.shift();
          }
          return origSub.apply(this, arguments);
        };
      };
      patch(window.WebGL2RenderingContext);
      patch(window.WebGLRenderingContext);
    })();
  `,
});

await send('Page.navigate', { url });

for (let i = 0; i < 80; i++) {
  if (await evaluate(`!!document.querySelector('canvas')`)) break;
  await sleep(250);
}

// 等内核就绪并跑一段渲染
for (let i = 0; i < 60; i++) {
  const t = await evaluate(`document.body ? document.body.innerText : ''`);
  if (/WebAssembly|已就绪|WASM/.test(t)) break;
  await sleep(250);
}
await evaluate(
  `new Promise(r => { let n=0; const t0=performance.now(); const tick=()=>{n++; if(performance.now()-t0>1500) r(n); else requestAnimationFrame(tick);}; requestAnimationFrame(tick); })`,
);

// 再画一条线，确保画面里一定有我们自己造的几何
const box = await evaluate(
  `(() => { const c=document.querySelector('canvas'); if(!c) return null; const r=c.getBoundingClientRect(); return {x:r.x,y:r.y,w:r.width,h:r.height}; })()`,
);

/**
 * 图案定义（屏幕像素）—— 抄自 `src/render/style.ts` 的 `LINETYPE_DASHES`。
 *
 * 刻意**不**从运行时代码里读。本脚本断言的是文档化的行为，不是「代码恰好算出
 * 什么」；把表抄一份在这里，改了那张表就必须来改这里，两边不可能悄悄分叉。
 *
 * 抄的是**整个图案**而不只是周期，因为「一个周期里有几段实线」是量周期时必须
 * 知道的：`center` = [18,6,4,6] 一个周期里有长划和点**两段**实线，按「一段实 +
 * 一段空」去量会得到 24 px 和 10 px 两个数交替出现，中位数毫无意义（这一点是
 * 实测撞出来的，不是推出来的）。
 */
const LINETYPE_SPEC = {
  continuous: null,
  dashed: [10, 6],
  dotted: [1.5, 4],
  dashdot: [12, 5, 2, 5],
  center: [18, 6, 4, 6],
  hidden: [7, 4],
};

const periodOf = (spec) => spec.reduce((a, b) => a + b, 0);
/** 一个周期里有几段「实」——图案从实段开始，所以是长度的一半向上取整。 */
const onRunsIn = (spec) => Math.ceil(spec.length / 2);

/**
 * 沿线的墨迹游程：把采样序列压成「连续有墨 / 连续无墨」的段落。
 *
 * 判定的关键量是**周期**，而不是实段或空段各自的长度。虚线的端头在片元着色器
 * 里带 1 px 羽化的渐隐，阈值一刀切下去，实段会被量长约 1 px、空段被量短约 1 px
 * —— 一多一少互相抵消，周期却是准的。断言单段长度会得到一个随羽化半径漂移的数。
 *
 * 周期的量法：取**相隔一个完整周期的两段实线的起点**之间的距离。对 `center`
 * 这种一个周期里有两段实线的图案，「相邻两段实线起点」的间距会在 18+6=24 与
 * 4+6=10 之间交替，只有每隔「每周期实段数」取一次才能得到真正的 34。
 */
function inkRuns(prof, threshold = 0.2) {
  const runs = [];
  let on = prof.samples[0].width > threshold;
  let n = 0;
  for (const s of prof.samples) {
    const now = s.width > threshold;
    if (now === on) n++;
    else {
      runs.push({ on, n });
      on = now;
      n = 1;
    }
  }
  runs.push({ on, n });
  return runs;
}

const median = (xs) => {
  if (xs.length === 0) return NaN;
  const s = [...xs].sort((a, b) => a - b);
  const m = s.length >> 1;
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
};

function analyseDash(prof, pax, pay, pbx, pby, style) {
  const len = Math.hypot(pbx - pax, pby - pay);
  const pxPerSample = len / (prof.samples.length - 1);
  const runs = inkRuns(prof);
  const spec = LINETYPE_SPEC[style];
  const expected = spec ? periodOf(spec) : 0;

  const ons = runs.filter((r) => r.on).map((r) => r.n * pxPerSample);
  const offs = runs.filter((r) => !r.on).map((r) => r.n * pxPerSample);
  // 首尾两段一定被线的端点截断，不参与统计。
  const innerOns = ons.slice(1, -1);
  const innerOffs = offs.slice(1, -1).filter((_, i) => i > 0);

  // 每段实线的**起点**在采样序列中的下标。
  const starts = [];
  let at = 0;
  for (const r of runs) {
    if (r.on) starts.push(at);
    at += r.n;
  }

  const k = spec ? onRunsIn(spec) : 1;
  const periods = [];
  for (let i = 0; i + k < starts.length; i++) {
    periods.push((starts[i + k] - starts[i]) * pxPerSample);
  }

  const gotPeriod = median(periods);
  console.log(`\n=== 线型游程（${style}） ===`);
  console.log(`采样间距 ${pxPerSample.toFixed(3)} px/点；游程 ${runs.length} 段（实 ${ons.length} / 空 ${offs.length}）`);
  console.log(`实段 中位 ${median(innerOns).toFixed(2)} px   空段 中位 ${median(innerOffs).toFixed(2)} px`);
  console.log(
    `周期 中位 ${gotPeriod.toFixed(2)} px   期望 ${expected} px（每周期 ${k} 段实线）   样本 ${periods.length} 个`,
  );
  console.log(`周期序列 ${periods.slice(0, 12).map((p) => p.toFixed(1)).join(', ')}${periods.length > 12 ? ', …' : ''}`);

  return { style, expected, gotPeriod, gaps: innerOffs.length, periods, pxPerSample };
}


const countEntities = async () => {
  const t = (await evaluate(`document.body ? document.body.innerText : ''`)) ?? '';
  const m = t.match(/图元\s+(\d+)/);
  return m ? Number(m[1]) : null;
};

let drawn = null;
let entBefore = null;
let entAfter = null;
if (box) {
  const cx = box.x + box.w / 2;
  const cy = box.y + box.h / 2;
  drawn = { ax: cx - 200, ay: cy - 80, bx: cx + 200, by: cy + 80 };

  const mouse = (type, x, y, btns = 0) =>
    send('Input.dispatchMouseEvent', {
      type,
      x,
      y,
      button: type === 'mouseMoved' ? 'none' : 'left',
      buttons: btns,
      clickCount: type === 'mousePressed' || type === 'mouseReleased' ? 1 : 0,
    });

  /**
   * 一次真实的单击：移动 → 按下 → 松开。
   *
   * 不能只发两次 `mousePressed` 而中间不松开：指针按下状态没有变化时，浏览器
   * 会把第二次按下合并掉，工具只收到第一个点，于是永远停在「指定下一点」。
   */
  const clickAt = async (x, y) => {
    await mouse('mouseMoved', x, y, 0);
    await mouse('mousePressed', x, y, 1);
    await mouse('mouseReleased', x, y, 0);
  };

  // 先点一下画布取得焦点，并让任何文本输入框失焦（否则单字母快捷键会被吃掉）。
  await clickAt(cx, cy);
  await evaluate(`document.activeElement && document.activeElement.blur()`);

  entBefore = await countEntities();

  // 切到直线工具（快捷键 L）。不切的话后面两次点击属于「选择」工具，
  // 图元数是不会变的 —— 那样「实体画在点击处」的断言就无从谈起。
  const key = (k, code) =>
    send('Input.dispatchKeyEvent', {
      type: 'keyDown',
      key: k,
      code,
      windowsVirtualKeyCode: k.toUpperCase().charCodeAt(0),
      nativeVirtualKeyCode: k.toUpperCase().charCodeAt(0),
      text: k,
      unmodifiedText: k,
    }).then(() => send('Input.dispatchKeyEvent', { type: 'keyUp', key: k, code }));
  await key('l', 'KeyL');
  await sleep(150);

  // 两点成线：第一点定锚，第二点成图元。
  await clickAt(drawn.ax, drawn.ay);
  await mouse('mouseMoved', drawn.bx, drawn.by, 0);
  await sleep(60);
  await clickAt(drawn.bx, drawn.by);

  entAfter = await countEntities();

  // ---- 线型：先让这条线「可被观察」 --------------------------------------
  //
  // 三件事必须一起做，少一件量到的都不是线型：
  //
  //   1. **结束绘制命令**。LineTool 是连续的，不结束的话下一次落点会再画一条；
  //   2. **清掉选中与悬停**。`resolveRenderStyle` 对选中态/悬停态强制
  //      `dash: null`（高亮必须是实线，否则高亮反而更难认），所以只要它被选中，
  //      线型就被盖掉了 —— 这一步忘了，虚线会被量成实线，而看起来像渲染器没实现；
  //   3. **把鼠标挪开**，否则它停在这条线上，悬停态又会盖掉线型。
  if (lineStyleArg) {
    const esc = () =>
      send('Input.dispatchKeyEvent', {
        type: 'rawKeyDown',
        key: 'Escape',
        code: 'Escape',
        windowsVirtualKeyCode: 27,
        nativeVirtualKeyCode: 27,
      }).then(() =>
        send('Input.dispatchKeyEvent', {
          type: 'keyUp',
          key: 'Escape',
          code: 'Escape',
          windowsVirtualKeyCode: 27,
          nativeVirtualKeyCode: 27,
        }),
      );
    await esc();
    await sleep(120);

    const applied = await evaluate(`(() => {
      const store = window.__unicadStore;
      if (!store) return 'no-handle';
      const s = store.getState();
      const last = s.doc.entities[s.doc.entities.length - 1];
      if (!last) return 'no-entity';
      s.updateEntityById(last.id, (e) => ({ ...e, lineStyle: ${JSON.stringify(lineStyleArg)} }), '测试线型');
      store.getState().clearSelection();
      store.getState().setHover(null);
      const e = store.getState().doc.entities.find((x) => x.id === last.id);
      return { id: last.id, lineStyle: e.lineStyle, color: e.color, selected: 0 };
    })()`);
    console.log(`\n=== 线型设置 ===\n${JSON.stringify(applied)}`);
    // 鼠标移到画布左上角，远离这条线。
    await mouse('mouseMoved', box.x + 12, box.y + 12, 0);
    await sleep(80);
  }

  await evaluate(
    `new Promise(r => { let n=0; const t0=performance.now(); const tick=()=>{n++; if(performance.now()-t0>800) r(n); else requestAnimationFrame(tick);}; requestAnimationFrame(tick); })`,
  );
}

// ---- 截图并分析画布区域 ----
if (wantSelectAll) {
  await evaluate(`
    (() => {
      const b = [...document.querySelectorAll('button')]
        .find(x => x.textContent.trim() === '全选');
      if (b) b.click();
      return !!b;
    })()
  `);
  await evaluate(
    `new Promise(r => { let n=0; const t0=performance.now(); const tick=()=>{n++; if(performance.now()-t0>600) r(n); else requestAnimationFrame(tick);}; requestAnimationFrame(tick); })`,
  );
}

// 先把尺寸标注的 DOM 覆盖层藏掉再截图。
//
// 本脚本量的是 **WebGL 画布**，而 `Page.captureScreenshot` 会把 DOM 一起截进来 ——
// 自动尺寸的标签是真实 DOM 元素，一旦画面里有选中或绘制中，它们就会混进像素
// 统计，甚至正好压在被测的圆环/直线剖面上，把「描边宽度」量成标签的边框。
// 现在恰好没有标签（截图时既无选中也无绘制中），但那是巧合，不是保证。
await evaluate(`(() => {
  const l = document.querySelector('.dim-layer');
  if (l) l.style.display = 'none';
})()`);
await evaluate(
  `new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)))`,
);

const shot = await send('Page.captureScreenshot', {
  format: 'png',
  clip:
    box && !wantFull
      ? { x: box.x, y: box.y, width: box.w, height: box.h, scale: 1 }
      : undefined,
  captureBeyondViewport: false,
});

const png = Buffer.from(shot.data, 'base64');
const shotPath = join(process.cwd(), 'canvas-shot.png');
writeFileSync(shotPath, png);

const img = decodePNG(png);
// 渲染器的清屏色是 #14161a
const stats = analyse(img, [0x14, 0x16, 0x1a]);

const up = await evaluate(`window.__glUp ? JSON.parse(JSON.stringify(window.__glUp)) : null`);

const segTol = 4;
const expected =
  drawn && box
    ? {
        ax: drawn.ax - box.x,
        ay: drawn.ay - box.y,
        bx: drawn.bx - box.x,
        by: drawn.by - box.y,
      }
    : null;
const hits = expected
  ? segmentHits(stats.brightPoints, expected.ax, expected.ay, expected.bx, expected.by, segTol)
  : 0;

console.log('=== 画布区域像素 ===');
console.log(`尺寸          ${stats.width} × ${stats.height}`);
console.log(`颜色种类      ${stats.colours}`);
console.log(`非背景像素    ${(stats.nonBgRatio * 100).toFixed(3)} %`);
console.log(`高亮像素      ${(stats.brightRatio * 100).toFixed(3)} %`);
console.log(`图元数        ${entBefore} → ${entAfter}`);
console.log('主要颜色      ' + stats.topColours.map((c) => `${c.hex}×${c.count}`).join('  '));

console.log('\n=== 实体几何落点 ===');
if (expected) {
  const len = Math.hypot(expected.bx - expected.ax, expected.by - expected.ay);
  console.log(
    `期望线段      (${expected.ax.toFixed(0)},${expected.ay.toFixed(0)}) → (${expected.bx.toFixed(0)},${expected.by.toFixed(0)})  长 ${len.toFixed(0)} px`,
  );
  console.log(`落在 ±${segTol}px 内  ${hits} 个亮点（描边 #e8e8e8 沿全长，应 ≳ 400）`);
  console.log(
    `亮像素包围盒  ${stats.brightBox ? `(${stats.brightBox.minX},${stats.brightBox.minY}) → (${stats.brightBox.maxX},${stats.brightBox.maxY})` : '（无）'}`,
  );
} else {
  console.log('未取得画布矩形，跳过落点检查');
}

console.log('\n=== 缓冲上传 ===');
console.log(JSON.stringify(up, null, 2));

// MSAA 采样数决定了「抗锯齿是硬件多重采样给的」还是「根本没有」。
// 无头 SwiftShader 有时会静默降级到 0 采样，此时画面里的锯齿比用户真机更严重 ——
// 不把 SAMPLES 打出来，就无法判断测到的粗细不均是否等价于用户看到的。
const glInfo = await evaluate(`(() => {
  const c = document.querySelector('canvas');
  if (!c) return null;
  const g = c.getContext('webgl2') || c.getContext('webgl');
  if (!g) return null;
  return {
    samples: g.getParameter(g.SAMPLES),
    dpr: window.devicePixelRatio,
    backingStore: c.width + 'x' + c.height,
    cssSize: c.clientWidth + 'x' + c.clientHeight,
  };
})()`);
console.log('\n=== GL 上下文 ===');
console.log(JSON.stringify(glInfo));

if (wantRuns) {
  const cx = Math.floor(stats.width / 2);
  const cy = Math.floor(stats.height / 2);
  // 阈值可调：默认 90 只认实体描边；调低到 25 左右就能量出栅格线的位置与间距。
  const lumArg = process.argv.find((a) => a.startsWith('--lum='));
  const lum = lumArg ? Number(lumArg.slice(6)) : 90;
  console.log(`\n=== 扫描线游程（亮度 > ${lum}） ===`);
  console.log(`横向 y=${cy}  ${formatRuns(scanRuns(img, 'x', cy, 0, stats.width, lum))}`);
  console.log(`纵向 x=${cx}  ${formatRuns(scanRuns(img, 'y', cx, 0, stats.height, lum))}`);
  // 想看某条特定扫描线（例如圆弧顶部切线方向）时用 --row=N。
  const rowArg = process.argv.find((a) => a.startsWith('--row='));
  if (rowArg) {
    const y = Number(rowArg.slice(6));
    const from = Number((process.argv.find((a) => a.startsWith('--x0=')) ?? '--x0=0').slice(5));
    const to = Number((process.argv.find((a) => a.startsWith('--x1=')) ?? `--x1=${stats.width}`).slice(5));
    console.log(`横向 y=${y} (x ${from}..${to})  ${formatRuns(scanRuns(img, 'x', y, from, to))}`);
  }
  // 实测描边宽度：找一条纵向扫描线上最长的亮游程，粗略反推线宽。
  const widest = scanRuns(img, 'x', cy, 0, stats.width)
    .filter((r) => r.on)
    .reduce((m, r) => Math.max(m, r.len), 0);
  console.log(`该行最宽亮游程 ${widest} px`);
}

// ---- 放大截图：看描边边缘 ---------------------------------------------------
const zoomArg = process.argv.find((a) => a.startsWith('--zoom='));
if (zoomArg) {
  const [zx, zy, zw, zh, zf] = zoomArg
    .slice('--zoom='.length)
    .split(',')
    .map(Number);
  const factor = zf || 6;
  const patch = cropImg(img, zx, zy, zw, zh);
  const zoomPath = join(process.cwd(), 'canvas-zoom.png');
  writeFileSync(zoomPath, encodePNG(scaleNearest(patch, factor)));
  console.log('\n=== 放大截图 ===');
  console.log(`裁剪 (${zx},${zy}) ${zw}×${zh} ×${factor} → ${zoomPath}`);

  // 肉眼看放大的图之外，再给一份逐行亮暗游程 —— 若曲线是断的，这里的
  // on/off 会呈现规律的间隔；若只是抗锯齿，间隔是 0~1 px 的抖动。
  console.log('逐行亮游程 (x 相对裁剪框):');
  const rows = Math.min(zh, 40);
  for (let y = 0; y < rows; y++) {
    const on = scanRuns(patch, 'x', y, 0, zw).filter((r) => r.on);
    if (!on.length) continue;
    console.log(`  y+${y}: ` + on.map((r) => `${r.start}~${r.start + r.len - 1}(${r.len})`).join(' '));
  }
}

// ---- 圆环描边宽度剖面 ------------------------------------------------------
//
// 只在屏幕上沿一整圈量宽度分布，才能把「周期性粗细不均 / 断续」和随机锯齿
// 区分开：断续会有宽度掉到 ~0 的采样点，随机锯齿只有一个窄的分布。
const ringArg = process.argv.find((a) => a.startsWith('--ring='));
const ringModelArg = process.argv.find((a) => a.startsWith('--ring-model='));

/**
 * model → 屏幕（画布局部）坐标。
 *
 * 与 `CanvasView.toWorld()` 严格互逆，系数取自页面暴露的 `window.__unicadView`。
 * 存在的理由：屏幕坐标是**画布尺寸的函数**，而画布尺寸会变（工具栏收拢一次就
 * 差 28px），取景随之改变 —— 于是硬编码的圆心量的就不是那个圆了，而结果会
 * 伪装成「描边断续」。用模型坐标描述图元才能与布局解耦。
 */
async function modelToScreen() {
  const v = await evaluate(
    `window.__unicadView ? JSON.parse(JSON.stringify(window.__unicadView)) : null`,
  );
  if (!v) return null;
  return {
    view: v,
    pt: (x, y) => ({
      x: (x - v.center.x) / v.scale + v.width / 2,
      y: v.height / 2 - (y - v.center.y) / v.scale,
    }),
    len: (d) => d / v.scale,
  };
}

if (ringArg || ringModelArg) {
  let rcx;
  let rcy;
  let rGuess;
  if (ringModelArg) {
    const [mx, my, mr] = ringModelArg
      .slice('--ring-model='.length)
      .split(',')
      .map(Number);
    const m = await modelToScreen();
    if (!m) {
      console.error('❌ --ring-model 需要页面暴露 window.__unicadView，但没读到。');
      process.exit(2);
    }
    const c = m.pt(mx, my);
    rcx = c.x;
    rcy = c.y;
    rGuess = m.len(mr);
    console.log(
      `\n模型坐标 (${mx},${my}) r=${mr} → 屏幕 (${rcx.toFixed(2)},${rcy.toFixed(2)}) r=${rGuess.toFixed(2)}  [scale ${m.view.scale.toFixed(4)}]`,
    );
  } else {
    [rcx, rcy, rGuess] = ringArg
      .slice('--ring='.length)
      .split(',')
      .map(Number);
  }
  // 先扫一遍半径：给的中心/半径只要大致对，让「平均墨量最大」的那一圈胜出。
  // 否则半径偏 1 px，剖面里就会出现大量假的「无墨」采样点。
  let rr = rGuess;
  let bestInk = -1;
  for (let r = rGuess - 4; r <= rGuess + 4; r += 0.25) {
    const ink = ringProfile(img, rcx, rcy, r).mean;
    if (ink > bestInk) {
      bestInk = ink;
      rr = r;
    }
  }
  const prof = ringProfile(img, rcx, rcy, rr);
  const cv = (prof.std / prof.mean) * 100;
  console.log('\n=== 圆环描边宽度剖面 ===');
  console.log(`圆心 (${rcx},${rcy})  半径 ${rr}  采样 ${prof.samples.length}`);
  console.log(
    `宽度 mean ${prof.mean.toFixed(3)}  min ${prof.min.toFixed(3)}  max ${prof.max.toFixed(3)}  std ${prof.std.toFixed(3)}  CV ${cv.toFixed(1)} %`,
  );
  const zero = prof.samples.filter((s) => s.width < 0.2).length;
  console.log(`几乎无墨的采样点 ${zero} / ${prof.samples.length}（>5% 即说明描边是断续的）`);

  // 谷间距 —— 判定「周期性」的周期到底是多少。
  //
  // 这是定位根因的关键数字：接缝问题锁定在**细分弦长**上（跟随半径与容差），
  // 虚线锁定在屏幕固定间距上，栅格锁定在栅格间距上。三者数值完全不同。
  const thr = prof.mean * 0.4;
  const troughs = [];
  let runStart = -1;
  for (let i = 0; i <= prof.samples.length; i++) {
    const low = i < prof.samples.length && prof.samples[i].width < thr;
    if (low && runStart < 0) runStart = i;
    if (!low && runStart >= 0) {
      troughs.push((runStart + i - 1) / 2);
      runStart = -1;
    }
  }
  const degPerSample = 360 / prof.samples.length;
  const arcPxPerDeg = (Math.PI * rr) / 180;
  const gaps = [];
  for (let i = 1; i < troughs.length; i++) {
    let d = troughs[i] - troughs[i - 1];
    if (d < 0) d += prof.samples.length;
    gaps.push(d);
  }
  const meanGap = gaps.length ? gaps.reduce((a, v) => a + v, 0) / gaps.length : 0;
  console.log(`谷（宽度 < 40% 均值）数量 ${troughs.length}`);
  console.log(
    `谷间距 平均 ${meanGap.toFixed(1)} 采样 = ${(meanGap * degPerSample * arcPxPerDeg).toFixed(2)} px 弧长` +
      (gaps.length
        ? `  min ${Math.min(...gaps).toFixed(0)} max ${Math.max(...gaps).toFixed(0)} 采样`
        : ''),
  );

  // 原始宽度序列，每字符 0~9 表示 0~2.25 px。周期性粗细不均会表现为
  // 「宽窄交替」的规律花纹，其周期就是细分弦长或接缝间距 —— 一眼可读。
  console.log('宽度序列（0=无墨 9=2.25px，每行 60 个采样）:');
  const digits = prof.samples.map((s) => String(Math.min(9, Math.max(0, Math.round(s.width * 4)))));
  for (let i = 0; i < digits.length; i += 60) {
    console.log('  ' + digits.slice(i, i + 60).join(''));
  }
  ringBroken = zero > prof.samples.length * 0.02;
  // 24 个扇区的最小/平均宽度，横条长度正比于平均宽度。
  console.log('扇区宽度（每 15°，条长 ∝ 平均宽度）:');
  const bins = 24;
  for (let b = 0; b < bins; b++) {
    const slice = prof.samples.filter((s) => Math.floor(s.deg / (360 / bins)) === b);
    const avg = slice.reduce((a, s) => a + s.width, 0) / slice.length;
    const mn = Math.min(...slice.map((s) => s.width));
    const bar = '█'.repeat(Math.round(avg * 8));
    console.log(`  ${String(b * 15).padStart(3)}°  avg ${avg.toFixed(2).padStart(5)}  min ${mn.toFixed(2).padStart(5)}  ${bar}`);
  }
}

// ---- 直线垂直宽度剖面 -------------------------------------------------------
const probeArg = process.argv.find((a) => a.startsWith('--probe='));
if (probeArg) {
  // `--probe=auto` 用**本次合成交互真正画出来的那条线**，坐标取自点击位置。
  // 硬编码一组数字是行不通的：画布尺寸一变，取景就变，量的就不是那条线了。
  //
  // 注意两层坐标系：`drawn` 是 client 坐标（点击就是按它发的），而 `img` 是
  // 截图，被 clip 到画布盒上 —— 必须减掉 box.x / box.y。忘了这一步的后果很隐蔽：
  // 线段被整体平移（实测偏移 268,76 = 左栏宽 + 页头 + 工具栏高），长度与方向都对，
  // 只是量的不是那条线，于是报「描边断续」。
  let pax;
  let pay;
  let pbx;
  let pby;
  if (probeArg === '--probe=auto') {
    if (!drawn || !box) {
      console.error('❌ --probe=auto 需要先成功画出那条线，但合成交互没有坐标。');
      process.exit(2);
    }
    pax = drawn.ax - box.x;
    pay = drawn.ay - box.y;
    pbx = drawn.bx - box.x;
    pby = drawn.by - box.y;
  } else {
    [pax, pay, pbx, pby] = probeArg
      .slice('--probe='.length)
      .split(',')
      .map(Number);
  }
  // 线型分析要把空档量准，采样点必须比「量描边宽度」密得多：dotted 的周期只有
  // 5.5 px，按默认的 240 点（≈1.8 px/点）会直接把图案采成混叠噪声。
  const prof = segmentProfile(img, pax, pay, pbx, pby, lineStyleArg ? { samples: 1600 } : {});
  const cv = (prof.std / prof.mean) * 100;
  console.log('\n=== 直线垂直宽度剖面 ===');
  console.log(`线段 (${pax},${pay}) → (${pbx},${pby})  长 ${Math.hypot(pbx - pax, pby - pay).toFixed(0)} px`);
  console.log(
    `宽度 mean ${prof.mean.toFixed(3)}  min ${prof.min.toFixed(3)}  max ${prof.max.toFixed(3)}  std ${prof.std.toFixed(3)}  CV ${cv.toFixed(1)} %`,
  );
  console.log(`无墨点 ${prof.samples.filter((s) => s.width < 0.2).length} / ${prof.samples.length}`);
  console.log('宽度序列（0=无墨 9=2.25px）:');
  const digits = prof.samples.map((s) => String(Math.min(9, Math.max(0, Math.round(s.width * 4)))));
  // 每行 60 个字符便于人眼比对；线型模式下采样点有 1600 多个，先按比例抽稀，
  // 否则这个「给人看」的输出本身就有四十行。
  const shown = lineStyleArg
    ? digits.filter((_, k) => k % Math.max(1, Math.round(digits.length / 240)) === 0)
    : digits;
  for (let i = 0; i < shown.length; i += 60) {
    console.log('  ' + shown.slice(i, i + 60).join(''));
  }
  const gapRatio =
    prof.samples.filter((s) => s.width < 0.2).length / prof.samples.length;
  if (lineStyleArg && LINETYPE_SPEC[lineStyleArg]) {
    // 虚线本来就有空档：dashed 的占空比是 6/16，约 37% 的采样点无墨是**正确**的。
    // 这里只确认「确实断开了」，周期是否对由 `dashResult` 负责。
    console.log(`无墨占比 ${(gapRatio * 100).toFixed(1)} %（线型模式下由图案决定，不做连续性断言）`);
    if (!(gapRatio > 0.1)) {
      console.error(`❌ 线型 ${lineStyleArg} 期望出现大量空档，实测只有 ${(gapRatio * 100).toFixed(1)} % —— 虚线被画成实线了。`);
      probeBroken = true;
    }
  } else {
    probeBroken = gapRatio > 0.02;
  }

  // ---- 线型：游程分析 ------------------------------------------------------
  if (lineStyleArg) {
    dashResult = analyseDash(prof, pax, pay, pbx, pby, lineStyleArg);

    // 复核：把视图放大一倍，同样的屏幕区段再量一次。
    //
    // 这一条是**区分两种实现**的判据，而不是「再来一遍」：
    //   - 图案定义在屏幕像素（本项目的选择）→ 周期不变，仍是 16 px；
    //   - 图案定义在模型空间 → 同样的屏幕距离里周期翻倍成 32 px。
    // 两种都能渲染出「看起来是虚线」的东西，只有这个数字分得开。
    //
    // 取景中心 = 画布中心，而本次划出的线段恰好以画布中心为中点，所以改 scale
    // 时中点不动、方向不变，原来那两个探针端点依然落在这条线上。
    const view = await evaluate(`(() => { const v = window.__unicadView; return v ? { scale: v.scale, center: v.center } : null; })()`);
    if (view) {
      await evaluate(`window.__unicadStore.getState().setView({ scale: ${view.scale} / 2 })`);
      await sleep(120);
      await evaluate(`new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)))`);

      const shot2 = await send('Page.captureScreenshot', {
        format: 'png',
        clip: { x: box.x, y: box.y, width: box.w, height: box.h, scale: 1 },
        captureBeyondViewport: false,
      });
      writeFileSync(join(process.cwd(), 'canvas-dash-zoom.png'), Buffer.from(shot2.data, 'base64'));
      const img2 = decodePNG(Buffer.from(shot2.data, 'base64'));
      const prof2 = segmentProfile(img2, pax, pay, pbx, pby, { samples: 1600 });
      const zoomed = analyseDash(prof2, pax, pay, pbx, pby, lineStyleArg);
      console.log('=== 放大 2× 后复核（期望周期不变） ===');
      dashResult = { ...dashResult, zoomedPeriod: zoomed.gotPeriod, zoomedGaps: zoomed.gaps };
    }
  }
}

// ---- 顶点流抓取：核对真正上传给 GPU 的坐标 -------------------------------
//
// 用来终结「描边为什么断断续续」这类争论：位置缓冲里的坐标是唯一事实，
// 从它算出的弦长、端点间距不需要任何关于渲染器「应该」做什么的假设。
if (process.argv.includes('--dump-verts')) {
  const verts = await evaluate(`window.__glVerts ? JSON.parse(JSON.stringify(window.__glVerts)) : []`);
  console.log('\n=== 顶点流（最近 ' + verts.length + ' 次 Float32 写入） ===');
  const isPos = (v) => Math.max(...v.head.map(Math.abs)) > 3;

  // 一次 buildLineBatch 会连写四次 Float32：pos、normal、side、width。
  // 前两者计数相同（每顶点 2 个 float），后两者为顶点数。
  const groups = [];
  for (let i = 0; i + 3 < verts.length; i++) {
    const a = verts[i];
    const b = verts[i + 1];
    const c = verts[i + 2];
    const d = verts[i + 3];
    if (a.count === b.count && c.count === d.count && a.count === c.count * 2 && isPos(a)) {
      groups.push({ pos: a, nrm: b, side: c, wid: d, verts: c.count });
    }
  }
  if (!groups.length) {
    console.log('未识别到批次写入');
  }
  for (const g of groups) {
    console.log(`批次: 顶点 ${g.verts}（段 ${g.verts / 6}）  pos dst=${g.pos.off}B  side/width dst=${g.side.off}B`);
  }
  const big = groups.reduce((m, g) => (!m || g.verts > m.verts ? g : m), null);
  if (big) {
    const P = big.pos.head;
    const N = big.nrm.head;
    const S = big.side.head;
    const W = big.wid.head;
    const nSeg = big.verts / 6;
    const sideOf = (k) => S[k];
    const widOf = (k) => W[k];
    console.log(`\n--- 接缝一致性检查（${nSeg} 段）---`);
    // 每个"接缝"边界：quad j 的端边必须与 quad j+1 的起边逐点重合。
    // 端边两点：k=2(side -1)、k=1(side +1)；起边两点：k=0(side -1)、k=3(side +1)。
    const PX = 4.3; // px per model unit（由栅格间距反推），仅用于换算缺口宽度
    let bad = 0;
    const samples = [];
    for (let j = 0; j + 1 < nSeg; j++) {
      for (const [ek, sk, side] of [[2, 0, -1], [1, 3, +1]]) {
        const ea = j * 6 + ek;
        const sb = (j + 1) * 6 + sk;
        const dPos = Math.hypot(P[ea * 2] - P[sb * 2], P[ea * 2 + 1] - P[sb * 2 + 1]);
        const dNrm = Math.hypot(N[ea * 2] - N[sb * 2], N[ea * 2 + 1] - N[sb * 2 + 1]);
        const dWid = Math.abs(W[ea] - W[sb]);
        const dSide = Math.abs(S[ea] - side);
        if (dPos > 1e-9 || dNrm > 1e-9 || dWid > 1e-9 || dSide > 1e-9) {
          bad++;
          if (samples.length < 6) {
            samples.push(
              `段${j}/${j + 1} side${side}: Δpos=${(dPos * PX).toFixed(3)}px Δnrm=${dNrm.toFixed(4)} Δwid=${dWid.toFixed(4)}`,
            );
          }
        }
      }
    }
    console.log(`不重合的接缝角点 ${bad} / ${(nSeg - 1) * 2}`);
    samples.forEach((s) => console.log('  ' + s));
    // 直接打印接缝附近的属性元组，肉眼核对。
    console.log('接缝附近顶点属性（段 4..6，即实体第 5 个=圆）：');
    for (let j = 4; j <= 6; j++) {
      for (let k = 0; k < 6; k++) {
        const vi = j * 6 + k;
        console.log(
          `  段${j} k=${k} side=${sideOf(vi).toFixed(0).padStart(3)} wid=${widOf(vi).toFixed(4)} ` +
            `n=(${N[vi * 2].toFixed(4)},${N[vi * 2 + 1].toFixed(4)}) p=(${P[vi * 2].toFixed(3)},${P[vi * 2 + 1].toFixed(3)})`,
        );
      }
    }
  }
}

if (wantFull) {
  const text = (await evaluate(`document.body ? document.body.innerText : ''`)) ?? '';
  console.log('\n=== 界面文本摘要 ===');
  console.log(text.replace(/\n+/g, ' | ').slice(0, 900));
}

console.log('\n截图已保存:', shotPath);

const blank = stats.nonBgRatio < 0.001;
const noUpload = up && up.buffersAllocated > 4 && up.buffersWritten === 0;
// 描边本身很细，但 430 px 长的线经过抗锯齿后亮点远不止 400 个。若几何被喂进了
// 错误的空间（全部挤到一个角上），这个数字会掉到接近 0。
const missed = expected !== null && hits < 150;
// 两次点击之间必须真的多出一个图元。否则「落点」断言毫无意义：默认的「选择」
// 工具下点击什么也不会发生，而画面上的栅格与示例图纸会掩盖这一点。
const notCreated = entBefore !== null && entAfter !== null && entAfter !== entBefore + 1;

// ---- 线型判定 ---------------------------------------------------------------
let dashBroken = false;
if (lineStyleArg && dashResult) {
  const { expected, gotPeriod, gaps, periods } = dashResult;
  console.log('\n=== 线型判定 ===');
  if (expected === 0) {
    if (gaps !== 0) {
      console.error(`❌ 线型 continuous 不该有空档，实测 ${gaps} 个`);
      dashBroken = true;
    } else {
      console.log('✅ 实线：零空档');
    }
  } else {
    const tol = Math.max(2, expected * 0.15);
    if (periods.length < 3) {
      console.error(`❌ 周期样本只有 ${periods.length} 个 —— 空档太少，量不出图案`);
      dashBroken = true;
    } else if (Math.abs(gotPeriod - expected) > tol) {
      console.error(
        `❌ 周期不符：实测中位 ${gotPeriod.toFixed(2)} px，期望 ${expected} px（容差 ±${tol.toFixed(1)}）`,
      );
      dashBroken = true;
    } else if (
      dashResult.zoomedPeriod !== undefined &&
      Math.abs(dashResult.zoomedPeriod - expected) > tol
    ) {
      console.error(
        `❌ 放大后周期变了：${dashResult.zoomedPeriod.toFixed(2)} px（期望仍是 ${expected}）—— 图案被定义在模型空间了？`,
      );
      dashBroken = true;
    } else {
      console.log(
        `✅ 线型 ${lineStyleArg}：空档 ${gaps} 个，周期中位 ${gotPeriod.toFixed(2)} px（期望 ${expected}）` +
          (dashResult.zoomedPeriod !== undefined
            ? `；放大 2× 后 ${dashResult.zoomedPeriod.toFixed(2)} px（不变）`
            : ''),
      );
    }
  }
}

if (blank) {
  console.log('\n❌ 画布空白（非背景像素 < 0.1%）');
} else if (notCreated) {
  console.log(`\n❌ 两次点击没有创建图元（${entBefore} → ${entAfter}）—— 直线工具没被激活？`);
} else if (missed) {
  console.log(`\n❌ 实体没有画在鼠标点击的位置（仅 ${hits} 个亮点落在期望线段上）`);
} else if (ringBroken || probeBroken) {
  const where = [ringBroken ? '圆环' : '', probeBroken ? '直线' : ''].filter(Boolean).join(' / ');
  console.log(`\n❌ ${where}描边断续：有 > 2% 的采样点几乎无墨 —— 四边形没有铺满整条线段？`);
} else if (dashBroken) {
  console.log('\n❌ 线型没有按预期渲染（见上）');
} else if (expected !== null) {
  console.log('\n✅ 画布有内容，且实体落在鼠标点击处');
  if (ringArg || probeArg) console.log('✅ 描边连续（法线方向宽度处处 > 0）');
  if (lineStyleArg && dashResult) console.log('✅ 线型生效');
} else {
  console.log('\n✅ 画布有内容');
}
if (noUpload) {
  console.log('❌ 分配了缓冲但从未写入 —— 上传被跳过');
}

// 非零退出码，让 CI / npm script 能真的判定失败（此前只打印 emoji，跑完总是 0）。
if (blank || notCreated || missed || noUpload || ringBroken || probeBroken || dashBroken) {
  process.exitCode = 1;
}

const glMsg = consoleMsgs.filter((m) => /WebGL|Error|error/i.test(m));
console.log('\n=== 控制台可疑输出 ===');
console.log('条数:', glMsg.length);
glMsg.slice(0, 6).forEach((m) => console.log(' ', m.slice(0, 150)));

ws.close();
chrome.kill();
await sleep(300);
try {
  rmSync(profile, { recursive: true, force: true });
} catch {
  /* ignore */
}
// 用 exitCode 而不是再算一遍表达式：这里原先重算了条件，却漏掉了 ringBroken /
// probeBroken —— 上面刚把退出码设成 1，紧接着被 process.exit(0) 覆盖，于是
// 「描边断续」时脚本照样以 0 退出。npm run 下看不出区别，接进 CI 才会发现。
process.exit(process.exitCode ?? 0);
