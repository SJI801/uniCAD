// TS 回退镶嵌器 vs Rust/WASM 镶嵌器 —— 输出一致性验证
//
// 为什么需要它：`SceneBuffer.run` 在内核尚未就绪时会走纯 TS 路径，如果两条
// 路径的顶点流或 strip 索引不一致，首帧几何就会和wasm帧「跳」一下，或者
// 直接画错。这里逐顶点、逐 strip 比对。
//
// 用法：node scripts/verify-tess-parity.mjs

import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const here = dirname(fileURLToPath(import.meta.url));
const pkgDir = join(here, '..', 'src', 'wasm', 'pkg');

const glue = await import('file://' + join(pkgDir, 'unicad_kernel.js').replace(/\\/g, '/'));
await glue.default(await readFile(join(pkgDir, 'unicad_kernel_bg.wasm')));

const TAG = { line: 0, circle: 1, arc: 2, ellipse: 3, polyline: 4 };

// ---- 与 src/core/kernel.ts 中同名函数保持一致的实现 ----

function arcSegments(radius, sweep, tol, maxSeg) {
  const sw = Math.abs(sweep);
  const cap = Math.max(maxSeg, 2);
  if (sw <= 1e-9) return 2;
  if (radius <= 1e-9 || tol <= 1e-12) return cap;
  const ratio = Math.max(-1, Math.min(1, 1 - Math.min(tol / radius, 1)));
  const half = Math.acos(ratio);
  if (half <= 1e-9) return cap;
  const n = Math.ceil(sw / (half * 2));
  return Math.max(2, Math.min(cap, n));
}

function tessellateTS(encoded, counts, tol, maxSeg) {
  const n = counts.length;
  const vertexCounts = new Int32Array(n);
  const segCounts = new Int32Array(n);
  let totalVerts = 0;
  let off = 0;

  for (let i = 0; i < n; i++) {
    const cnt = counts[i];
    const tag = encoded[off];
    let verts = 0;
    let segs = 0;
    switch (tag) {
      case TAG.line:
        verts = 2;
        break;
      case TAG.circle: {
        const r = Math.abs(encoded[off + 3]);
        segs = arcSegments(r, 2 * Math.PI, tol, maxSeg);
        verts = segs + 1;
        break;
      }
      case TAG.arc: {
        const r = Math.abs(encoded[off + 3]);
        let sweep = encoded[off + 5] - encoded[off + 4];
        if (sweep < 0) sweep += 2 * Math.PI;
        segs = arcSegments(r, sweep, tol, maxSeg);
        verts = segs + 1;
        break;
      }
      case TAG.ellipse: {
        const rx = Math.abs(encoded[off + 3]);
        const ry = Math.abs(encoded[off + 4]);
        segs = arcSegments(Math.max(rx, ry), 2 * Math.PI, tol, maxSeg);
        verts = segs + 1;
        break;
      }
      case TAG.polyline: {
        const closed = encoded[off + 1];
        const pts = Math.max(0, Math.floor((cnt - 2) / 2));
        verts = pts < 2 ? 0 : pts + (closed !== 0 ? 1 : 0);
        break;
      }
    }
    vertexCounts[i] = verts;
    segCounts[i] = segs;
    totalVerts += verts;
    off += cnt;
  }

  const vertices = new Float32Array(totalVerts * 2);
  const strips = new Uint32Array(n * 2);
  let vo = 0;
  off = 0;

  for (let i = 0; i < n; i++) {
    const cnt = counts[i];
    const tag = encoded[off];
    const vStart = vo;
    switch (tag) {
      case TAG.line:
        vertices[vo * 2] = encoded[off + 1];
        vertices[vo * 2 + 1] = encoded[off + 2];
        vertices[vo * 2 + 2] = encoded[off + 3];
        vertices[vo * 2 + 3] = encoded[off + 4];
        vo += 2;
        break;
      case TAG.circle: {
        const cx = encoded[off + 1];
        const cy = encoded[off + 2];
        const r = Math.abs(encoded[off + 3]);
        const s = segCounts[i];
        for (let k = 0; k <= s; k++) {
          const a = (k / s) * 2 * Math.PI;
          vertices[vo * 2] = cx + r * Math.cos(a);
          vertices[vo * 2 + 1] = cy + r * Math.sin(a);
          vo++;
        }
        break;
      }
      case TAG.arc: {
        const cx = encoded[off + 1];
        const cy = encoded[off + 2];
        const r = Math.abs(encoded[off + 3]);
        const a0 = encoded[off + 4];
        let sweep = encoded[off + 5] - a0;
        if (sweep < 0) sweep += 2 * Math.PI;
        const s = segCounts[i];
        for (let k = 0; k <= s; k++) {
          const a = a0 + (k / s) * sweep;
          vertices[vo * 2] = cx + r * Math.cos(a);
          vertices[vo * 2 + 1] = cy + r * Math.sin(a);
          vo++;
        }
        break;
      }
      case TAG.ellipse: {
        const cx = encoded[off + 1];
        const cy = encoded[off + 2];
        const rx = encoded[off + 3];
        const ry = encoded[off + 4];
        const rot = encoded[off + 5];
        const cs = Math.cos(rot);
        const sn = Math.sin(rot);
        const s = segCounts[i];
        for (let k = 0; k <= s; k++) {
          const p = (k / s) * 2 * Math.PI;
          const ex = rx * Math.cos(p);
          const ey = ry * Math.sin(p);
          vertices[vo * 2] = cx + ex * cs - ey * sn;
          vertices[vo * 2 + 1] = cy + ex * sn + ey * cs;
          vo++;
        }
        break;
      }
      case TAG.polyline: {
        if (vertexCounts[i] === 0) break;
        const closed = encoded[off + 1];
        const pts = Math.floor((cnt - 2) / 2);
        const base = off + 2;
        for (let p = 0; p < pts; p++) {
          vertices[vo * 2] = encoded[base + p * 2];
          vertices[vo * 2 + 1] = encoded[base + p * 2 + 1];
          vo++;
        }
        if (closed !== 0) {
          vertices[vo * 2] = encoded[base];
          vertices[vo * 2 + 1] = encoded[base + 1];
          vo++;
        }
        break;
      }
    }
    strips[i * 2] = vStart;
    strips[i * 2 + 1] = vo;
    off += cnt;
  }
  return { vertices, strips };
}

// ---- 场景构造 ----

function pack(prims) {
  const counts = new Uint32Array(prims.length);
  const encoded = new Float64Array(prims.reduce((a, p) => a + p.length, 0));
  let o = 0;
  for (let i = 0; i < prims.length; i++) {
    counts[i] = prims[i].length;
    for (const v of prims[i]) encoded[o++] = v;
  }
  return { encoded, counts };
}

const cases = [
  {
    name: '全部图元类型混合',
    prims: [
      [TAG.line, 0, 0, 100, 50],
      [TAG.circle, 10, 10, 7],
      [TAG.arc, -5, 3, 12, 0.3, 2.2],
      [TAG.ellipse, 4, 4, 9, 3, 0.7],
      [TAG.polyline, 0, 0, 0, 5, 5, 9, 1, 4, 4, 5],
      [TAG.polyline, 1, 1, 1, 8, 3, 9, 0],
    ],
  },
  { name: '单条直线', prims: [[TAG.line, 1, 2, 3, 4]] },
  { name: '单个圆', prims: [[TAG.circle, 0, 0, 6]] },
  { name: '跨 0 角度圆弧', prims: [[TAG.arc, 0, 0, 5, 5.8, 0.9]] },
  { name: '顺时针圆弧', prims: [[TAG.arc, 1, 1, 4, 2.5, 0.4]] },
  { name: '退化：r=0 圆', prims: [[TAG.circle, 2, 2, 0]] },
  { name: '退化：单点多段线', prims: [[TAG.polyline, 0, 3, 3]] },
  { name: '退化：0 点多段线', prims: [[TAG.polyline, 0]] },
  { name: '小半径圆弧', prims: [[TAG.arc, 0, 0, 0.4, 0, 1.2]] },
  { name: '大半径圆弧', prims: [[TAG.arc, 0, 0, 5000, 0, 3]] },
];

let failures = 0;

for (const tol of [0.05, 0.5, 0.005]) {
  for (const maxSeg of [512, 64]) {
    const tess = new glue.SceneTessellator(tol, maxSeg);
    for (const c of cases) {
      const { encoded, counts } = pack(c.prims);
      const ts = tessellateTS(encoded, counts, tol, maxSeg);

      let wv;
      let ws;
      try {
        tess.tessellate(encoded, counts);
        wv = tess.vertex_array();
        ws = tess.strips;
      } catch (e) {
        console.log(`❌ [tol=${tol} maxSeg=${maxSeg}] ${c.name}: WASM 抛错 ${e.message}`);
        failures++;
        continue;
      }

      let maxErr = 0;
      const len = Math.max(ts.vertices.length, wv.length);
      for (let i = 0; i < len; i++) {
        const a = ts.vertices[i] ?? NaN;
        const b = wv[i] ?? NaN;
        if (Number.isNaN(a) && Number.isNaN(b)) continue;
        const d = Math.abs(a - b);
        if (!Number.isNaN(d)) maxErr = Math.max(maxErr, d);
      }
      const stripsMatch =
        ts.strips.length === ws.length && Array.from(ts.strips).every((x, i) => x === ws[i]);

      const ok = maxErr < 1e-3 && stripsMatch;
      if (!ok) {
        failures++;
        console.log(
          `❌ [tol=${tol} maxSeg=${maxSeg}] ${c.name}\n` +
            `   TS   verts=${ts.vertices.length / 2} strips=[${Array.from(ts.strips).join(',')}]\n` +
            `   WASM verts=${wv.length / 2} strips=[${Array.from(ws).join(',')}]\n` +
            `   最大误差=${maxErr}`,
        );
      } else {
        console.log(
          `✅ [tol=${tol} maxSeg=${maxSeg}] ${c.name}  verts=${wv.length / 2} 误差=${maxErr}`,
        );
      }
    }
    tess.free();
  }
}

console.log(failures === 0 ? '\n✅ 全部一致' : `\n❌ ${failures} 项不一致`);
process.exit(failures === 0 ? 0 : 1);
