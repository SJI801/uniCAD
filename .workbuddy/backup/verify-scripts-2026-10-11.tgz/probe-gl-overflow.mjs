// WebGL buffer 上传探针
//
// 用户报告控制台出现成片的：
//   WebGL: INVALID_VALUE: bufferSubData: buffer overflow
//
// Chrome 对 WebGL 警告不附带 JS 调用栈，所以这里在页面里 patch
// `bufferData` / `bufferSubData`，自己复算
// 「目标缓冲实际容量 vs 本次写入字节数」，命中时记录完整参数与调用栈。
// 同时统计两类调用的次数，用来确认「容量增长式上传」确实消掉了
// 每帧重新分配的抖动。
//
// 用法：node scripts/probe-gl-overflow.mjs [url]

import { spawn } from 'node:child_process';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const CHROME = 'C:/Program Files/Google/Chrome/Application/chrome.exe';
// 取第一个非 `--flag` 参数作为 URL —— 之前直接读 argv[2]，于是
// `node probe-gl-overflow.mjs --big` 会把 `--big` 当成地址，脚本静默地
// 什么都没测就报「0 越界」。
const url = process.argv.slice(2).find((a) => !a.startsWith('--')) ?? 'http://127.0.0.1:5273/';
const big = process.argv.includes('--big');

// 先确认目标真的在服务，否则后面所有「0 越界」都是空话。
try {
  const probe = await fetch(url, { method: 'HEAD' });
  if (!probe.ok) throw new Error(`HTTP ${probe.status}`);
} catch (e) {
  console.error(`❌ 无法访问 ${url}（${e.message}）—— 请先启动 dev 或 preview 服务再跑本检查。`);
  process.exit(2);
}
const port = 9800 + Math.floor(Math.random() * 100);
const profile = mkdtempSync(join(tmpdir(), 'unicad-gl-'));

const args = [
  '--headless=new',
  '--enable-unsafe-swiftshader',
  '--use-gl=angle',
  '--use-angle=swiftshader',
  `--remote-debugging-port=${port}`,
  '--no-first-run',
  '--no-default-browser-check',
  `--user-data-dir=${profile}`,
  `--window-size=${big ? '2560,1440' : '1440,900'}`,
  ...(big ? ['--force-device-scale-factor=2'] : []),
  'about:blank',
];
const chrome = spawn(CHROME, args, { stdio: 'ignore' });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

let list;
for (let i = 0; i < 80; i++) {
  try {
    list = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
    if (list.length) break;
  } catch {
    /* not up yet */
  }
  await sleep(250);
}
const page = list.find((t) => t.type === 'page');
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((res, rej) => {
  ws.onopen = res;
  ws.onerror = rej;
});

let id = 0;
const pending = new Map();
const consoleMsgs = [];
ws.onmessage = (ev) => {
  const m = JSON.parse(ev.data);
  if (m.id && pending.has(m.id)) {
    const { resolve } = pending.get(m.id);
    pending.delete(m.id);
    resolve(m.result);
    return;
  }
  if (m.method === 'Runtime.consoleAPICalled') {
    consoleMsgs.push(
      m.params.type + ': ' + m.params.args.map((a) => a.value ?? a.description).join(' '),
    );
  }
};
const send = (method, params = {}) => {
  const i = ++id;
  ws.send(JSON.stringify({ id: i, method, params }));
  return new Promise((r) => pending.set(i, { resolve: r }));
};
const evaluate = async (expr) =>
  (await send('Runtime.evaluate', { expression: expr, awaitPromise: true, returnByValue: true }))
    .result?.value;

await send('Runtime.enable');
await send('Page.enable');

await send('Page.addScriptToEvaluateOnNewDocument', {
  source: `
    (() => {
      const log = [];
      const stats = { bufferData: 0, bufferSubData: 0, reallocs: 0, maxBytes: 0 };
      Object.defineProperty(window, '__glOverflow', { value: log });
      Object.defineProperty(window, '__glStats', { value: stats });

      const patch = (Ctor, name) => {
        if (!Ctor || !Ctor.prototype || !Ctor.prototype.bufferSubData) return;
        const proto = Ctor.prototype;

        const origData = proto.bufferData;
        proto.bufferData = function (target, sizeOrData, usage) {
          stats.bufferData++;
          if (typeof sizeOrData === 'number') {
            stats.reallocs++;
            stats.maxBytes = Math.max(stats.maxBytes, sizeOrData);
          }
          return origData.apply(this, arguments);
        };

        const origSub = proto.bufferSubData;
        proto.bufferSubData = function (target, dstByteOffset, srcData, srcOffset, length) {
          stats.bufferSubData++;
          try {
            if (srcData && typeof srcData.BYTES_PER_ELEMENT === 'number') {
              const size = this.getBufferParameter(target, this.BUFFER_SIZE);
              const es = srcData.BYTES_PER_ELEMENT;
              const so = srcOffset === undefined ? 0 : srcOffset;
              const len = length === undefined ? srcData.length - so : length;
              const need = dstByteOffset + len * es;
              if (need > size || so + len > srcData.length) {
                log.push({
                  backend: name,
                  bufferSize: size,
                  writeBytes: need,
                  overflowBy: need - size,
                  dstByteOffset,
                  srcOffset: so,
                  length: len,
                  elemSize: es,
                  ctor: srcData.constructor.name,
                  srcLen: srcData.length,
                  stack: (new Error().stack || '').split('\\n').slice(1, 7).join('\\n'),
                });
              }
            }
          } catch (e) {
            log.push({ error: String(e) });
          }
          return origSub.apply(this, arguments);
        };
      };
      patch(window.WebGL2RenderingContext, 'webgl2');
      patch(window.WebGLRenderingContext, 'webgl1');
    })();
  `,
});

await send('Page.navigate', { url });

for (let i = 0; i < 60; i++) {
  if (await evaluate(`!!document.querySelector('canvas')`)) break;
  await sleep(250);
}

// 记录「稳定后」的基线，用于对比每帧分配次数
await evaluate(
  `new Promise(r => { let n=0; const t0=performance.now(); const tick=()=>{n++; if(performance.now()-t0>1500) r(n); else requestAnimationFrame(tick);}; requestAnimationFrame(tick); })`,
);
const baseline = await evaluate(`JSON.parse(JSON.stringify(window.__glStats))`);

const box = await evaluate(
  `(() => { const c=document.querySelector('canvas'); if(!c) return null; const r=c.getBoundingClientRect(); return {x:r.x,y:r.y,w:r.width,h:r.height}; })()`,
);

if (box) {
  const cx = box.x + box.w / 2;
  const cy = box.y + box.h / 2;
  const mouse = (type, x, y, btns = 0) =>
    send('Input.dispatchMouseEvent', {
      type,
      x,
      y,
      button: type === 'mouseMoved' ? 'none' : 'left',
      buttons: btns,
      clickCount: type === 'mousePressed' || type === 'mouseReleased' ? 1 : 0,
    });
  const key = (type, keyName, code, mods = 0) =>
    send('Input.dispatchKeyEvent', {
      type,
      key: keyName,
      code,
      windowsVirtualKeyCode: keyName === 'a' ? 65 : 0,
      modifiers: mods,
    });

  // 画一屏图元，制造较大的顶点批次
  for (let i = 0; i < 8; i++) {
    const y = cy - 160 + i * 40;
    await mouse('mouseMoved', cx - 300, y, 0);
    await mouse('mousePressed', cx - 300, y, 1);
    await mouse('mouseMoved', cx + 300, y + 15, 1);
    await mouse('mousePressed', cx + 300, y + 15, 1);
    await mouse('mouseReleased', cx + 300, y + 15, 1);
  }

  // 全选 —— grips 会让 overlay 点批次明显变大
  await key('keyDown', 'a', 'KeyA', 2); // Ctrl
  await key('keyUp', 'a', 'KeyA', 2);

  // 缩放：把网格推到自适应边界
  await send('Input.dispatchMouseEvent', {
    type: 'mouseWheel',
    x: cx,
    y: cy,
    deltaX: 0,
    deltaY: big ? -2400 : -1200,
  });
  await sleep(150);
  await send('Input.dispatchMouseEvent', {
    type: 'mouseWheel',
    x: cx,
    y: cy,
    deltaX: 0,
    deltaY: 2400,
  });

  await evaluate(
    `new Promise(r => { let n=0; const t0=performance.now(); const tick=()=>{n++; if(performance.now()-t0>2000) r(n); else requestAnimationFrame(tick);}; requestAnimationFrame(tick); })`,
  );
}

const finalStats = await evaluate(`JSON.parse(JSON.stringify(window.__glStats))`);
const overflow = await evaluate(`window.__glOverflow.slice(0, 5)`);
const count = await evaluate(`window.__glOverflow.length`);

console.log('=== 环境 ===');
console.log('url:', url, big ? '(大窗口 + DPR 2)' : '(默认)');
console.log('\n=== 上传统计 ===');
console.log('稳定后基线:', JSON.stringify(baseline));
console.log('全流程结束:', JSON.stringify(finalStats));
console.log(
  `\n稳定渲染期间 bufferData 增长次数 = ${finalStats.reallocs - baseline.reallocs}` +
    `（bufferSubData ${finalStats.bufferSubData - baseline.bufferSubData} 次）`,
);
console.log('单次最大分配 =', (finalStats.maxBytes / 1024 / 1024).toFixed(2), 'MB');

console.log('\n=== bufferSubData 越界记录 ===');
console.log('总数:', count);
for (const o of overflow ?? []) console.log(JSON.stringify(o, null, 2));

const glWarn = consoleMsgs.filter((m) => /WebGL/i.test(m));
console.log('\n=== 控制台 WebGL 警告 ===');
console.log('条数:', glWarn.length);
glWarn.slice(0, 5).forEach((m) => console.log(' ', m.slice(0, 160)));

const dep = consoleMsgs.filter((m) => /deprecated/i.test(m));
console.log('\n=== 弃用警告 ===');
console.log('条数:', dep.length);

// 「没有越界」必须建立在「确实上传过东西」之上。上传次数为 0 说明要么渲染器
// 一帧都没跑、要么钩子没装上 —— 那种情况下报「通过」等于没测。
const measuredNothing = (finalStats?.bufferSubData ?? 0) === 0;
if (measuredNothing) {
  console.log('\n❌ 探针一次上传都没记录到 —— 这次检查没有测到任何东西');
}

console.log(
  count === 0 && glWarn.length === 0 && !measuredNothing
    ? '\n✅ 无越界、无 GL 警告'
    : '\n❌ 存在问题',
);

ws.close();
chrome.kill();
await sleep(300);
try {
  rmSync(profile, { recursive: true, force: true });
} catch {
  /* ignore */
}
process.exit(count === 0 && glWarn.length === 0 && !measuredNothing ? 0 : 1);
