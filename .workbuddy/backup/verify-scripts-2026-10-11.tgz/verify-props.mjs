// 属性面板验证
//
// 需求原话：「属性中任何参数都能修改」。这句话的对立面是**没报错但改不动** ——
// 控件显示着 10、实体里还是 5，截图看起来完全正常。所以本脚本的核心不是「有没有
// 输入框」，而是：
//
//   1. 面板列出的每个参数都有一个可编辑控件（不是 .readonly 文本）；
//   2. 改完之后**实体里真的变了**，而且变到的是正确的位置（读 store 核对）。
//
// 第 1 条用参数名的**集合相等**来断言：期望哪些 key、就只允许哪些 key。少一个
// （漏了某个参数）或多一个（改名了）都会红，这样「新加参数忘了写 applyTo」和
// 「新加参数忘了加进面板」都跑不掉。
//
// 第 2 条的每一格都要说清**反解规则**，因为它们不是定义而是选择：
//   - 直线改「长度」→ 固定起点、沿当前方向移动终点（不是缩放整条线）；
//   - 直线改「角度」→ 长度不变、绕起点旋转；
//   - 圆改「直径/周长/面积」→ 反解出半径；
//   - 圆弧改「扫掠角」→ 固定起始角；改「弧长」→ 固定圆心角、缩放半径；
//   - 椭圆改「面积」→ 等比缩放两条半轴（长短轴之比与旋转角不变）；
//   - 多段线改「总长度」→ 以质心为中心等比缩放（形状不变）。
// 这些规则如果实现错了，控件依然「能用」，值也依然「变了」—— 所以必须逐个核
// 对没被改动的量。
//
// 另外还有：派生量在界面上有说明（title）、改一次 = 撤销一步、多选可批量改、
// 「随层」能清掉覆盖。以及全程零控制台错误。
//
// 用法：node scripts/verify-props.mjs [url] [--shot]

import { spawn } from 'node:child_process';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const CHROME = 'C:/Program Files/Google/Chrome/Application/chrome.exe';
const url = process.argv.slice(2).find((a) => !a.startsWith('--')) ?? 'http://127.0.0.1:5273/';
const wantShot = process.argv.includes('--shot');

try {
  const probe = await fetch(url, { method: 'HEAD' });
  if (!probe.ok) throw new Error(`HTTP ${probe.status}`);
} catch (e) {
  console.error(`❌ 无法访问 ${url}（${e.message}）—— 请先 npm run dev 或 npm run preview 再跑本检查。`);
  process.exit(2);
}

const port = 9500 + Math.floor(Math.random() * 100);
const profile = mkdtempSync(join(tmpdir(), 'unicad-props-'));

const chrome = spawn(
  CHROME,
  [
    '--headless=new',
    '--enable-unsafe-swiftshader',
    '--use-gl=angle',
    '--use-angle=swiftshader',
    `--remote-debugging-port=${port}`,
    '--no-first-run',
    '--no-default-browser-check',
    `--user-data-dir=${profile}`,
    '--window-size=1440,900',
    'about:blank',
  ],
  { stdio: 'ignore' },
);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

let list = null;
for (let i = 0; i < 80; i++) {
  try {
    list = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
    if (list.length) break;
  } catch {
    /* not up yet */
  }
  await sleep(250);
}
const page = list.find((t) => t.type === 'page');
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((res, rej) => {
  ws.onopen = res;
  ws.onerror = rej;
});

let id = 0;
const pending = new Map();
const problems = [];

ws.onmessage = (ev) => {
  const m = JSON.parse(ev.data);
  if (m.id && pending.has(m.id)) {
    pending.get(m.id)(m.result);
    pending.delete(m.id);
    return;
  }
  if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') {
    problems.push('console.error: ' + m.params.args.map((a) => a.value ?? a.description).join(' '));
  }
  if (m.method === 'Runtime.exceptionThrown') {
    const d = m.params.exceptionDetails;
    problems.push('exception: ' + (d?.exception?.description ?? d?.text));
  }
};

const send = (method, params = {}) => {
  const i = ++id;
  ws.send(JSON.stringify({ id: i, method, params }));
  return new Promise((r) => pending.set(i, r));
};

const evaluate = async (expr) =>
  (await send('Runtime.evaluate', { expression: expr, awaitPromise: true, returnByValue: true }))
    .result?.value;

await send('Runtime.enable');
await send('Page.enable');

/** 等 React 把这次状态变更渲染完（两帧足够：一帧提交、一帧布局）。 */
const settle = () =>
  evaluate(
    `new Promise(r => requestAnimationFrame(() => requestAnimationFrame(() => requestAnimationFrame(r))))`,
  );

const waitForApp = async () => {
  for (let i = 0; i < 80; i++) {
    if (await evaluate(`!!document.querySelector('canvas.canvas-gl')`)) break;
    await sleep(250);
  }
  for (let i = 0; i < 60; i++) {
    const t = (await evaluate(`document.body ? document.body.innerText : ''`)) ?? '';
    if (/WASM|已就绪/.test(t)) break;
    await sleep(250);
  }
  await sleep(400);
  await settle();
};

// ---------------------------------------------------------------------------
// 页面内小工具
// ---------------------------------------------------------------------------

/**
 * 装一套页面内辅助函数。
 *
 * 改一个受控输入框不能只设 `el.value`：React 在 value 上装了 setter，直接赋值
 * 会被它认作「外部改写」而丢弃，onChange 一次都不会触发，于是脚本会得到「改了但
 * 没反应」的结论 —— 而真实原因只是脚本不会用 React。必须走原型上的原生 setter，
 * 再补一个冒泡的 input 事件，React 才会认为这是用户输入。
 */
const installHelpers = () =>
  evaluate(`(() => {
    const all = () => Array.from(document.querySelectorAll('[data-param]'));
    window.__props = {
      el: (p) => all().find((x) => x.dataset.param === p) || null,
      rows: () => Array.from(document.querySelectorAll('.panel-body .prop-label')).map((lab) => {
        const ctl = lab.nextElementSibling;
        const inner = ctl ? Array.from(ctl.querySelectorAll('[data-param]')) : [];
        const own = ctl && ctl.dataset && ctl.dataset.param ? [ctl.dataset.param] : [];
        // 真正的控件可能是 ctl 本身，也可能被一层 <span class="vec2-row|num-row">
        // 包着（一对坐标、或「输入框 + 随层按钮」）。取里面那个带 data-param 的
        // 元素来判定 tag，否则「颜色/线型/坐标」整组都会被误判成 <span>。
        const owner = own.length ? ctl : inner[0] || null;
        return {
          label: lab.textContent.replace(/·\\s*$/, '').trim(),
          derived: lab.classList.contains('derived'),
          tag: owner ? owner.tagName.toLowerCase() : null,
          readOnly: !!(ctl && (ctl.dataset.readonly === '1' || ctl.querySelector('[data-readonly]'))),
          type: owner && owner.tagName === 'INPUT' ? owner.type : null,
          params: own.concat(inner.map((n) => n.dataset.param)),
          title: (owner && owner.title) || (ctl && ctl.title) || (lab.title || ''),
        };
      }),
      set: (p, v) => {
        const el = window.__props.el(p);
        if (!el) return 'missing';
        if (el.type === 'checkbox') { el.click(); return 'checkbox'; }
        const proto = el instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
        Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, String(v));
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return el instanceof HTMLSelectElement ? 'select' : 'input';
      },
      commit: (p) => {
        const el = window.__props.el(p);
        if (!el || el instanceof HTMLSelectElement) return false;
        el.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
        return true;
      },
      clickParam: (p) => { const el = window.__props.el(p); if (el) el.click(); return !!el; },
      clickSel: (s) => { const e = document.querySelector(s); if (e) e.click(); return !!e; },
    };
    return true;
  })()`);

/** 改一个参数，然后提交（数字/文本要补一次 Enter；下拉和勾选改完即生效）。 */
const setParam = async (param, value) => {
  const kind = await evaluate(`window.__props.set(${JSON.stringify(param)}, ${JSON.stringify(String(value))})`);
  if (kind === 'missing') {
    check(`控件存在：${param}`, false, '找不到 data-param');
    return false;
  }
  await settle();
  if (kind === 'input') {
    // 两次 evaluate 之间必须让出事件循环：草稿值是 React state，同一次同步调用里
    // 紧接着派发 Enter，处理函数拿到的还是**上一次渲染**的闭包（draft === null），
    // 于是 commit 直接返回，改了跟没改一样。
    await evaluate(`window.__props.commit(${JSON.stringify(param)})`);
    await settle();
  }
  return true;
};

const readEnt = (entId) =>
  evaluate(
    `(() => {
      const e = window.__unicadStore.getState().doc.entities.find((x) => x.id === ${JSON.stringify(entId)});
      return e ? JSON.parse(JSON.stringify(e)) : null;
    })()`,
  );

const selectIds = async (ids) => {
  await evaluate(`window.__unicadStore.getState().select(${JSON.stringify(ids)})`);
  await settle();
};

const undo = async () => {
  await evaluate(`window.__unicadStore.getState().undo()`);
  await settle();
};

// ---------------------------------------------------------------------------
// 断言
// ---------------------------------------------------------------------------

const failures = [];
const check = (name, ok, detail = '') => {
  console.log(`${ok ? '✓' : '✗'} ${name}${detail ? `  — ${detail}` : ''}`);
  if (!ok) failures.push(name);
};

const near = (a, b, tol = 1e-6) => Math.abs(a - b) <= tol;
/**
 * 相对容差比较。
 *
 * 数值输入框把提交值保留到 **6 位小数**（`round6`）——这是刻意的：一个属性框不该
 * 承载 14 位有效数字，那只会让用户看到 21.350000000000001。代价是「输入 2π·10、
 * 期望反解出正好 10」这种往返不可能精确成立：62.831853 反解回来是 9.99999999。
 * 所以凡是经过输入框往返的量都按相对误差判，而不是拿绝对 1e-9 去卡。
 */
const relNear = (a, b, tol = 1e-6) => Math.abs(a - b) <= tol * Math.max(1, Math.abs(b));
const DEG = 180 / Math.PI;

console.log(`\n目标: ${url}\n`);
await send('Page.navigate', { url });
await waitForApp();
await installHelpers();

// ---------------------------------------------------------------------------
// 夹具：清空示例图纸，换成一组尺寸已知的图元
//
// 全部用 store 直接选中，不合成鼠标点击 —— 属性面板的验证不需要命中测试，
// 绕开它可以让这个脚本快得多，也让它只因为面板的问题而失败。
// ---------------------------------------------------------------------------

const created = await evaluate(`(() => {
  const store = window.__unicadStore;
  if (!store) return 'no-handle';
  store.getState().selectAll();
  store.getState().deleteSelection();
  const L = store.getState().doc.layers[0].id;
  const base = (id, type) => ({ id, type, layer: L, color: null, lineStyle: null, lineWeight: null });
  const fx = [
    { ...base('t-line', 'line'), a: { x: 0, y: 0 }, b: { x: 100, y: 0 } },
    { ...base('t-circle', 'circle'), center: { x: 0, y: 0 }, radius: 10 },
    { ...base('t-arc', 'arc'), center: { x: 0, y: 0 }, radius: 10, startAngle: 0, endAngle: Math.PI / 2 },
    { ...base('t-ellipse', 'ellipse'), center: { x: 0, y: 0 }, rx: 30, ry: 10, rotation: 0 },
    { ...base('t-poly', 'polyline'), points: [{ x: 0, y: 0 }, { x: 50, y: 0 }, { x: 50, y: 30 }], closed: false },
  ];
  store.getState().addEntities(fx, '测试图元');
  store.getState().zoomToFit();
  return store.getState().doc.entities.map((e) => e.id);
})()`);
check('夹具创建成功（5 个图元）', Array.isArray(created) && created.length === 5, `= ${JSON.stringify(created)}`);
await settle();

check(
  '属性页签存在',
  await evaluate(`window.__props.clickSel('.panel-tab:nth-child(2)')`),
);
await settle();

// ---------------------------------------------------------------------------
// 1. 参数集合：每个参数的 key 必须与期望**完全一致**，且都可编辑
// ---------------------------------------------------------------------------

const COMMON = ['layer', 'color', 'lineStyle', 'lineWeight', 'name'];
const EXPECTED = {
  't-line': [...COMMON, 'a.x', 'a.y', 'b.x', 'b.y', 'length', 'angle'],
  't-circle': [...COMMON, 'center.x', 'center.y', 'radius', 'diameter', 'circumference', 'area'],
  't-arc': [...COMMON, 'center.x', 'center.y', 'radius', 'startAngle', 'endAngle', 'sweep', 'arcLength'],
  't-ellipse': [...COMMON, 'center.x', 'center.y', 'rx', 'ry', 'rotation', 'area'],
  't-poly': [...COMMON, 'v0.x', 'v0.y', 'v1.x', 'v1.y', 'v2.x', 'v2.y', 'count', 'closed', 'length'],
};

const rowCache = {};
for (const entId of ['t-line', 't-circle', 't-arc', 't-ellipse', 't-poly']) {
  await selectIds([entId]);
  const rows = await evaluate(`window.__props.rows()`);
  rowCache[entId] = rows;

  const params = rows.flatMap((r) => r.params).sort();
  const want = [...EXPECTED[entId]].sort();
  check(
    `${entId}：参数集合与期望一致（${want.length} 项）`,
    JSON.stringify(params) === JSON.stringify(want),
    params.length === want.length ? '集合差异见下' : `实测 ${params.length} 项 / 期望 ${want.length} 项`,
  );
  if (JSON.stringify(params) !== JSON.stringify(want)) {
    const extra = params.filter((p) => !want.includes(p));
    const missing = want.filter((p) => !params.includes(p));
    if (extra.length) console.log(`    多出: ${extra.join(', ')}`);
    if (missing.length) console.log(`    缺少: ${missing.join(', ')}`);
  }

  // 核心：几何区不许有只读行
  const ro = rows.filter((r) => r.readOnly);
  check(`${entId}：没有任何只读参数`, ro.length === 0, ro.map((r) => r.label).join(', '));

  // 每个控件都必须是 input/select，而不是 <span>
  const spans = rows.filter((r) => r.tag !== 'input' && r.tag !== 'select');
  check(`${entId}：每个参数都是输入控件`, spans.length === 0, spans.map((r) => `${r.label}=<${r.tag}>`).join(', '));

  // 派生量必须写清反解规则
  const derivedNoHint = rows.filter((r) => r.derived && r.title.trim().length < 4);
  check(
    `${entId}：派生量都带说明（${rows.filter((r) => r.derived).length} 个）`,
    derivedNoHint.length === 0,
    derivedNoHint.map((r) => r.label).join(', '),
  );
}

// ---------------------------------------------------------------------------
// 2. 逐格改值：既要知道「变了」，更要知道「变到哪」
// ---------------------------------------------------------------------------

const LN = 't-line';
await selectIds([LN]);

// ---- 直线：起点直接改 ----
let before = await readEnt(LN);
await setParam('a.x', -25);
let after = await readEnt(LN);
check('line：起点 X 改为 -25', near(after.a.x, -25) && near(after.a.y, before.a.y) && near(after.b.x, before.b.x), `a=(${after.a.x},${after.a.y}) b=(${after.b.x},${after.b.y})`);

// ---- 直线：长度固定起点、沿原方向 ----
before = await readEnt(LN);
const len0 = Math.hypot(before.b.x - before.a.x, before.b.y - before.a.y);
const dir0 = Math.atan2(before.b.y - before.a.y, before.b.x - before.a.x);
await setParam('length', 250);
after = await readEnt(LN);
const len1 = Math.hypot(after.b.x - after.a.x, after.b.y - after.a.y);
const dir1 = Math.atan2(after.b.y - after.a.y, after.b.x - after.a.x);
check(
  'line：改长度 → 新长度正确',
  near(len1, 250, 1e-6),
  `实测 ${len1.toFixed(6)}（原 ${len0.toFixed(3)}）`,
);
check('line：改长度 → 起点不动', near(after.a.x, before.a.x) && near(after.a.y, before.a.y), `a=(${after.a.x},${after.a.y})`);
check('line：改长度 → 方向不变', near(dir1, dir0, 1e-9), `${(dir1 * DEG).toFixed(4)}° vs ${(dir0 * DEG).toFixed(4)}°`);

// ---- 直线：角度固定起点、长度不变 ----
before = await readEnt(LN);
const lenBefore = Math.hypot(before.b.x - before.a.x, before.b.y - before.a.y);
await setParam('angle', 30);
after = await readEnt(LN);
const lenAfter = Math.hypot(after.b.x - after.a.x, after.b.y - after.a.y);
const dirAfter = Math.atan2(after.b.y - after.a.y, after.b.x - after.a.x) * DEG;
check('line：改角度 → 角度正确', near(dirAfter, 30, 1e-6), `实测 ${dirAfter.toFixed(6)}°`);
check('line：改角度 → 长度不变', near(lenAfter, lenBefore, 1e-6), `${lenAfter.toFixed(6)} vs ${lenBefore.toFixed(6)}`);
check('line：改角度 → 起点不动', near(after.a.x, before.a.x) && near(after.a.y, before.a.y));

// ---- 撤销：一次编辑 = 一步 ----
before = await readEnt(LN);
await setParam('b.y', 77);
const edited = await readEnt(LN);
await undo();
after = await readEnt(LN);
check(
  'line：改一个参数 = 撤销一步',
  near(edited.b.y, 77) && near(after.b.y, before.b.y, 1e-9),
  `改后 ${edited.b.y} → 撤销后 ${after.b.y}（改前 ${before.b.y}）`,
);

// ---- 圆：半径 / 直径 / 周长 / 面积 ----
const CI = 't-circle';
await selectIds([CI]);
await setParam('radius', 12.5);
let c = await readEnt(CI);
check('circle：改半径', near(c.radius, 12.5), `r=${c.radius}`);

await setParam('diameter', 40);
c = await readEnt(CI);
check('circle：改直径 → r = 直径/2', near(c.radius, 20, 1e-9), `r=${c.radius}`);

await setParam('circumference', 62.83185307179586);
c = await readEnt(CI);
check('circle：改周长 → r = 周长/2π', relNear(c.radius, 10), `r=${c.radius}`);

await setParam('area', 706.8583470577034);
c = await readEnt(CI);
check('circle：改面积 → r = √(面积/π)', relNear(c.radius, 15), `r=${c.radius}`);
check('circle：圆心未被牵连', near(c.center.x, 0) && near(c.center.y, 0), `c=(${c.center.x},${c.center.y})`);

// ---- 圆弧：扫掠角 / 弧长 / 起止角 ----
const AR = 't-arc';
await selectIds([AR]);
await setParam('sweep', 120);
let a = await readEnt(AR);
let sweep = ((a.endAngle - a.startAngle) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2);
check('arc：改扫掠角 → 120°', near(sweep * DEG, 120, 1e-6), `实测 ${(sweep * DEG).toFixed(6)}°`);
check('arc：改扫掠角 → 起始角不动', near(a.startAngle, 0, 1e-12), `start=${(a.startAngle * DEG).toFixed(4)}°`);
check('arc：改扫掠角 → 半径不动', near(a.radius, 10, 1e-12), `r=${a.radius}`);

await setParam('arcLength', 20);
a = await readEnt(AR);
sweep = ((a.endAngle - a.startAngle) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2);
check('arc：改弧长 → 半径 = 弧长/扫掠角', near(a.radius * sweep, 20, 1e-9), `r·θ = ${(a.radius * sweep).toFixed(6)}`);
check('arc：改弧长 → 扫掠角不变', near(sweep * DEG, 120, 1e-6), `${(sweep * DEG).toFixed(6)}°`);

await setParam('startAngle', 45);
a = await readEnt(AR);
check('arc：改起始角 → 45°', near(a.startAngle * DEG, 45, 1e-9), `start=${(a.startAngle * DEG).toFixed(6)}°`);

await setParam('endAngle', 200);
a = await readEnt(AR);
check('arc：改终止角 → 200°', near(a.endAngle * DEG, 200, 1e-9), `end=${(a.endAngle * DEG).toFixed(6)}°`);

// 退化保护：扫掠角 0 / 360 都要被夹住，不能悄悄变成空圆弧
await setParam('sweep', 360);
a = await readEnt(AR);
sweep = ((a.endAngle - a.startAngle) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2);
check('arc：扫掠角输入 360° 被夹到 <360（不退化成空圆弧）', sweep > 1e-3 && sweep * DEG < 360, `实测 ${(sweep * DEG).toFixed(3)}°`);

// ---- 椭圆：面积等比缩放，比例与旋转角不变 ----
const EL = 't-ellipse';
await selectIds([EL]);
const e0 = await readEnt(EL);
await setParam('area', Math.PI * 20 * 40);
let el = await readEnt(EL);
check('ellipse：改面积 → π·rx·ry 等于输入', relNear(Math.PI * el.rx * el.ry, Math.PI * 800), `π·rx·ry=${(Math.PI * el.rx * el.ry).toFixed(6)}`);
check('ellipse：改面积 → 长短轴之比不变', near(el.rx / el.ry, e0.rx / e0.ry, 1e-9), `${(el.rx / el.ry).toFixed(9)} vs ${(e0.rx / e0.ry).toFixed(9)}`);
check('ellipse：改面积 → 旋转角不变', near(el.rotation, e0.rotation, 1e-12));
check('ellipse：改面积 → 中心不动', near(el.center.x, e0.center.x) && near(el.center.y, e0.center.y));

await setParam('rotation', 30);
el = await readEnt(EL);
check('ellipse：改旋转角 → 30°', near(el.rotation * DEG, 30, 1e-9), `${(el.rotation * DEG).toFixed(6)}°`);

// ---- 多段线：顶点、结构、总长度 ----
const PL = 't-poly';
await selectIds([PL]);
await setParam('v1.y', 42);
let pl = await readEnt(PL);
check('polyline：改顶点 → 该点变了、其它点没动', near(pl.points[1].y, 42) && near(pl.points[0].x, 0) && near(pl.points[2].y, 30), JSON.stringify(pl.points));

const plLen = (p, closed) => {
  let s = 0;
  for (let i = 0; i + 1 < p.length; i++) s += Math.hypot(p[i + 1].x - p[i].x, p[i + 1].y - p[i].y);
  if (closed && p.length > 2) s += Math.hypot(p[0].x - p[p.length - 1].x, p[0].y - p[p.length - 1].y);
  return s;
};

before = await readEnt(PL);
const ratio0 = Math.hypot(before.points[1].x - before.points[0].x, before.points[1].y - before.points[0].y) /
               Math.hypot(before.points[2].x - before.points[1].x, before.points[2].y - before.points[1].y);
await setParam('length', 500);
pl = await readEnt(PL);
check('polyline：改总长度 → 总长正确', near(plLen(pl.points, pl.closed), 500, 1e-6), `实测 ${plLen(pl.points, pl.closed).toFixed(6)}`);
const ratio1 = Math.hypot(pl.points[1].x - pl.points[0].x, pl.points[1].y - pl.points[0].y) /
               Math.hypot(pl.points[2].x - pl.points[1].x, pl.points[2].y - pl.points[1].y);
check('polyline：改总长度 → 形状（边长之比）不变', near(ratio1, ratio0, 1e-9), `${ratio1.toFixed(9)} vs ${ratio0.toFixed(9)}`);

await setParam('count', 5);
pl = await readEnt(PL);
check('polyline：顶点数 3 → 5', pl.points.length === 5, `= ${pl.points.length}`);

await setParam('count', 2);
pl = await readEnt(PL);
check('polyline：顶点数降到 2 后不再降（下限保护）', pl.points.length === 2, `= ${pl.points.length}`);

await setParam('closed', 1);
pl = await readEnt(PL);
check('polyline：闭合可切换', pl.closed === true, `closed=${pl.closed}`);

// ---------------------------------------------------------------------------
// 3. 公共参数：下拉、随层、批量
// ---------------------------------------------------------------------------

await selectIds([LN]);
await setParam('layer', (await evaluate(`window.__unicadStore.getState().doc.layers[0].id`)));
let ln = await readEnt(LN);
check('common：图层下拉可选（回到 layer-0）', ln.layer === 'layer-0', `layer=${ln.layer}`);

await setParam('color', '#ff0000');
ln = await readEnt(LN);
check('common：改颜色 → 成为对象自身的覆盖', ln.color === '#ff0000', `color=${ln.color}`);
const hasInherit = await evaluate(`!!window.__props.el('color.inherit')`);
check('common：有了覆盖后出现「随层」按钮', hasInherit === true);
await evaluate(`window.__props.clickParam('color.inherit')`);
await settle();
ln = await readEnt(LN);
check('common：点「随层」→ 覆盖被清除', ln.color === null, `color=${ln.color}`);
const inheritBack = await evaluate(`!!window.__props.el('color.inherit')`);
check('common：「随层」后按钮变回不可点的状态标记', inheritBack === false);

// 随层时色块显示的是**实际生效**的图层颜色
const layerColor = await evaluate(`window.__unicadStore.getState().doc.layers[0].color`);
const swatch = await evaluate(`(() => { const el = window.__props.el('color'); return el ? el.value : null; })()`);
check('common：随层时色块显示图层色（不是灰占位）', swatch === layerColor, `${swatch} vs 图层 ${layerColor}`);

await setParam('lineStyle', 'dashed');
ln = await readEnt(LN);
check('common：线型下拉可选 → dashed', ln.lineStyle === 'dashed', `lineStyle=${ln.lineStyle}`);

await setParam('lineWeight', 0.5);
ln = await readEnt(LN);
check('common：线宽可改 → 0.5', near(ln.lineWeight, 0.5), `lineWeight=${ln.lineWeight}`);

await setParam('name', '主梁');
ln = await readEnt(LN);
check('common：名称可改', ln.name === '主梁', `name=${ln.name}`);

// ---------------------------------------------------------------------------
// 4. 多选：通用参数批量改，且一步撤销
// ---------------------------------------------------------------------------

await selectIds([LN, CI, AR]);
const multiRows = await evaluate(`window.__props.rows()`);
const multiParams = multiRows.flatMap((r) => r.params);
check(
  '多选：只列出通用参数（不含几何、不含名称）',
  multiParams.includes('layer') && multiParams.includes('color') && multiParams.includes('lineStyle') &&
    multiParams.includes('lineWeight') && !multiParams.includes('name') && !multiParams.includes('a.x'),
  multiParams.join(', '),
);

const multiNote = await evaluate(`(document.querySelector('.panel-body') || {}).innerText || ''`);
check('多选：提示里写明了会应用到全部', /同时应用/.test(multiNote), multiNote.split('\n')[0]?.slice(0, 60));

// 三者的 lineWeight 各不相同（直线 0.5、其余随层）→ 应标成「多值」。
// 断言落在**控件上**而不是内部字段上：占位文案是用户真正会看到的那个信号，
// 内部有没有 mixed 标志对用户毫无意义。
const placeholder = await evaluate(`(() => { const el = window.__props.el('lineWeight'); return el ? el.placeholder : null; })()`);
check('多选：取值不一致的数值输入显示「多值」占位', placeholder === '多值', `placeholder=${placeholder}`);

const mixedLayerOpt = await evaluate(`(() => {
  const el = window.__props.el('layer');
  return el ? Array.from(el.options).map((o) => o.value) : null;
})()`);
const docLayers = await evaluate(`window.__unicadStore.getState().doc.layers.map((l) => l.id)`);
check(
  '多选：图层下拉列出全部图层',
  Array.isArray(mixedLayerOpt) && JSON.stringify(mixedLayerOpt) === JSON.stringify(docLayers),
  `下拉 ${JSON.stringify(mixedLayerOpt)} / 文档 ${JSON.stringify(docLayers)}`,
);

// 只改**选中的三个**，第四个（椭圆）没被选中，必须原封不动 —— 这条防的是
// 「批量」被实现成「整个文档」。所以断言分两组，而不是把四个都塞进一个
// every()：那样第四个必然失败，而失败原因是脚本自己写错了，看起来却像产品有 bug。
const otherBefore = await readEnt(EL);
await setParam('color', '#00ff88');
const selAfter = await Promise.all([readEnt(LN), readEnt(CI), readEnt(AR)]);
const otherAfter = await readEnt(EL);
check(
  '多选：改颜色 → 应用到全部所选',
  selAfter.every((e) => e.color === '#00ff88'),
  selAfter.map((e) => String(e.color)).join(', '),
);
check(
  '多选：未选中的图元没有被波及',
  otherAfter.color === otherBefore.color,
  `椭圆 ${String(otherBefore.color)} → ${String(otherAfter.color)}`,
);

await undo();
const undone = await Promise.all([readEnt(LN), readEnt(CI), readEnt(AR)]);
check(
  '多选：一次撤销回滚全部（一条命令）',
  undone.every((e) => e.color === null),
  undone.map((e) => String(e.color)).join(', '),
);

// ---------------------------------------------------------------------------
// 5. 截图 + 收尾
// ---------------------------------------------------------------------------

if (wantShot) {
  await selectIds([CI]);
  await settle();
  const box = await evaluate(`(() => {
    const c = document.querySelector('canvas.canvas-gl');
    if (!c) return null;
    const r = c.getBoundingClientRect();
    return { x: r.x, y: r.y, w: r.width, h: r.height };
  })()`);
  const shot = await send('Page.captureScreenshot', { format: 'png' });
  writeFileSync(join(process.cwd(), 'props-panel.png'), Buffer.from(shot.data, 'base64'));
  if (box) console.log(`\n截图已保存: props-panel.png（画布 ${box.w}×${box.h}）`);
}

console.log('\n=== 控制台 ===');
console.log(`可疑输出 ${problems.length} 条`);
problems.slice(0, 6).forEach((p) => console.log('  ' + p.slice(0, 200)));
check('全程零控制台错误', problems.length === 0);

ws.close();
chrome.kill();
await sleep(300);
try {
  rmSync(profile, { recursive: true, force: true });
} catch {
  /* ignore */
}

console.log(`\n${failures.length === 0 ? '✅ 属性面板：全部通过' : `❌ ${failures.length} 项失败`}`);
failures.forEach((f) => console.log(`   ✗ ${f}`));
process.exit(failures.length === 0 ? 0 : 1);
